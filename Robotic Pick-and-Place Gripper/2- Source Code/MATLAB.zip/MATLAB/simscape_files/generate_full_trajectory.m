function [t_vec, q_traj] = generate_full_trajectory(P_start, P_end, q, trajectory_type, T_total, dt)
% GENERATE_FULL_TRAJECTORY
% Generates the COMPLETE joint trajectory from start to end
% Outputs:
%   t_vec   : time vector [s] (1×N)
%   q_traj  : joint angles [rad] (N×4) → ready to export to Simscape, CSV, Excel, etc.
%
% Usage example:
%   [t, q] = generate_full_trajectory([0.5;0;0.4], [0.5;0.15;0.4], 'circle', 8, 0.02);
%   plot(t, q);  % or save to file

    arguments
        P_start (3,1) double
        P_end   (3,1) double
        q       (4,1) double
        trajectory_type char {mustBeMember(trajectory_type,{'line','circle'})}
        T_total (1,1) double {mustBePositive}
        dt      (1,1) double {mustBePositive} = 0.02   % default 50 Hz
    end

    t_vec = 0:dt:T_total;
    N = length(t_vec);
    
    

    q_traj = zeros(N, 4); 
    q_prev = inverse_kinematics_func(zeros(4,1), P_start);
    
    %fprintf('Generating %s trajectory: %.1f seconds, %d points...\n', upper(trajectory_type), T_total, N);

    % Main loop — generate all q values
    for i = 1:N

        if i == 1
            q_prev = q;
        end
        q = generate_trajectory(t_vec(i), T_total, P_start, P_end, trajectory_type, q_prev);
        q_traj(i,:) = q';           % store as row
        q_prev = q;                 % continuity for next step
    end
    
    % Final verification
    X_final = forward_kinematics_func(q_traj(end,:)');
    end_error = norm(X_final - P_end);
    
    fprintf('Trajectory complete!\n');

    %fprintf('Desired Position: [ %.4f, %.4f, %.4f ]\n', P_end);
    %fprintf('Actual Position: [ %.4f, %.4f, %.4f ]\n', X_final);

    %fprintf('Final position error: %.3e m\n', end_error);
    
    if end_error < 1e-4
        fprintf('SUCCESS: Trajectory is perfect — ready for Simscape!\n');
    else
        fprintf('WARNING: Some error — check workspace.\n');
    end
end