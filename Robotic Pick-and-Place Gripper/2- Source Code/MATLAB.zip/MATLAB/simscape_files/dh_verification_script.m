% --- Part 1: Initialization and Symbolic Definitions ---

clear; clc; close all; % Clear workspace, command window, and close figures

% Define symbolic variables for the joint angles
syms q1 q2 q3 q4

% Define the link lengths from your notes
l1 = 0.04355; % Corresponds to d1 in your table
l2 = 0.14;    % Corresponds to a2
l3 = 0.1341;  % Corresponds to a3
l4 = 0.04544;  % Corresponds to a4

% --- Part 2: DH Parameters and Transformation Matrices ---

% Create the DH Parameter Table: [theta, d, a, alpha]
% This table is created directly from your handwritten notes.
DH_table = [      q1,   l1,   0,  pi/2;
             q2+pi/2,    0,  l2,    pi;
                  q3,    0,  l3,    pi;
                  q4,    0,  l4,     0];

% Create a function fo4 the transformation matrix
% Note: You can also save this as a separate file named 'transformation_matrix.m'
% in the same folder.
T_func = @(theta, d, a, alpha) [cos(theta), -sin(theta)*cos(alpha),  sin(theta)*sin(alpha), a*cos(theta);
                                sin(theta),  cos(theta)*cos(alpha), -cos(theta)*sin(alpha), a*sin(theta);
                                0,           sin(alpha),             cos(alpha),            d;
                                0,           0,                      0,                     1];

% Calculate the individual transformation matrices
T01 = T_func(DH_table(1,1), DH_table(1,2), DH_table(1,3), DH_table(1,4));
T12 = T_func(DH_table(2,1), DH_table(2,2), DH_table(2,3), DH_table(2,4));
T23 = T_func(DH_table(3,1), DH_table(3,2), DH_table(3,3), DH_table(3,4));
T34 = T_func(DH_table(4,1), DH_table(4,2), DH_table(4,3), DH_table(4,4));

% Calculate the total transformation matrix from base to end-effector
T04 = T01 * T12 * T23 * T34;

% --- Part 3: Symbolic and Numerical Forward Kinematics ---

% Extract the symbolic end-effector position
symbolic_end_effector_position = T04(1:3, 4);

% Display the symbolic result (can be complex)
fprintf('Symbolic End-Effector Position (X, Y, Z):\n');
disp(simplify(symbolic_end_effector_position));

% --- Part 4: Verification with Numerical Values ---

% Define specific joint angles for testing (in radians)
% These are the values you will also input into your Simscape model.
q1_val = 0;      % Example value for joint 1
q2_val = 0;      % Example value for joint 2
q3_val = 0;      % Example value for joint 3
q4_val = 0;      % Example value for joint 4

% Substitute the numerical values into the symbolic equations
numerical_end_effector_position = subs(symbolic_end_effector_position, ...
                                       {q1, q2, q3, q4}, ...
                                       {q1_val, q2_val, q3_val, q4_val});

% Display the numerical result from your DH calculation
fprintf('\nCalculated End-Effector Position for the given angles:\n');
disp(double(numerical_end_effector_position));