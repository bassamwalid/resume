function generate_kinematics()
% SCRIPT TO GENERATE NUMERICAL KINEMATICS FUNCTIONS.
% This function is called once by your main kinematics files to generate 
% the stable, fast numerical functions needed for Simulink.

% 1. Setup Symbolic Variables
q1 = sym('q1','real');
q2 = sym('q2','real');
q3 = sym('q3','real');
q4 = sym('q4','real');

q_sym = [q1;q2;q3;q4];
% 2. Define Constants and Transformations (Copied from your old jacobian_matrix.m)
l1 = 0.0436; % d1
l2 = 0.14;    % a2
l3 = 0.1329;  % a3
l4 = 0; % a4

% --- DH Parameters ---
DH_table = [q1, l1, 0, pi/2; q2+pi/2, 0, l2, pi; q3, 0, l3, pi; q4, 0, l4, 0];

T_func = @(theta, d, a, alpha) [cos(theta), -sin(theta)*cos(alpha), sin(theta)*sin(alpha), a*cos(theta);
                                 sin(theta), cos(theta)*cos(alpha), -cos(theta)*sin(alpha), a*sin(theta);
                                 0, sin(alpha), cos(alpha), d; 0, 0, 0, 1];
T01 = T_func(DH_table(1,1), DH_table(1,2), DH_table(1,3), DH_table(1,4));
T12 = T_func(DH_table(2,1), DH_table(2,2), DH_table(2,3), DH_table(2,4));
T23 = T_func(DH_table(3,1), DH_table(3,2), DH_table(3,3), DH_table(3,4));
T34 = T_func(DH_table(4,1), DH_table(4,2), DH_table(4,3), DH_table(4,4));

T04_sym = T01 * T12 * T23 * T34;

% 3. calculate the position function

X_sym = T04_sym(1:3, 4);

% 3. Calculate the Jacobian
J_sym = jacobian(X_sym, q_sym);

% 4. Generate Numerical Functions
matlabFunction(X_sym, 'File', 'fk_numerical', 'Vars', {q_sym});
matlabFunction(J_sym, 'File', 'jacobian_numerical', 'Vars', {q_sym});

fprintf('Transormation matrix done');
