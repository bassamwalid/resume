function q_next = generate_trajectory(t, T_total, P_start, P_end, trajectory_type, q_previous)
% GENERATE_TRAJECTORY
% Generates joint angles q for a given time t during a straight line or circular motion
% in 3D Cartesian space. Uses constant velocity (no acceleration profile).

    % Input normalization
    P0 = P_start(:);               % Force start position as 3x1 column vector [x;y;z]
    P1 = P_end(:);                 % Force end position as 3x1 column vector [x;y;z]
    q_guess = q_previous(:);       % Use previous joint solution as initial guess for IK (very important!)


    % Trajectory type selection
    if strcmpi(trajectory_type, 'line')

        % ====================== STRAIGHT LINE MOTION =========================
        gradient = (P1 - P0)/T_total;
        X_target = P0 + gradient * t;     



    elseif strcmpi(trajectory_type, 'circle')
        % ====================== CIRCULAR (HALF CIRCLE) MOTION =================
        mid_xy   = (P0(1:2) + P1(1:2)) / 2;                  % Center of the circle (midpoint between start and end)

        dir_xy      = P1(1:2) - P0(1:2);

        if norm(dir_xy) < 1e-8
            error('Start and end points are identical');
        end

        perp = [-dir_xy(2); dir_xy(1)];
        perp = perp / norm(perp);
        offset = dot(P0(1:2) - mid_xy, perp);
        center_xy = mid_xy + offset * perp;
        

        % calcualtions for X & Y
        r0 = norm(P0(1:2) - center_xy);     % initial radius
        r1 = norm(P1(1:2) - center_xy);     % final radius

        b = (r1 - r0) / T_total;
        r_t = r0 + b * t;                       % current radius
        if r_t < 0.005, r_t = 0.005; end



        %calculating angle theta
        theta0 = atan2(P0(2)-center_xy(2), P0(1)-center_xy(1));  % initial angle
        theta1 = atan2(P1(2)-center_xy(2), P1(1)-center_xy(1));  % final angle 

        theta_T = theta1 - theta0;
        theta_T = mod(theta_T + pi, 2*pi) - pi;

        omega = theta_T / T_total;

        theta = theta0 + omega * t;               % current angle (this is the key!)

        % calculations for Z
        c_z   = (P1(3) - P0(3)) / T_total;         % Z velocity


        %final equation
        X_target = [ center_xy(1) + r_t * cos(theta);
                     center_xy(2) + r_t * sin(theta);
                     P0(3) + c_z * t                   ];



    else
        error('trajectory_type must be ''line'' or ''circle''');
    end

    % ----- Inverse Kinematics ---------------------------------------------------
    % Solve IK using the previous joint angles as initial guess
    % This ensures continuity and fast convergence → smooth robot motion!
    q_next = inverse_kinematics_func(q_guess, X_target);

end