% TEST_SCRIPT_LINE_ONLY.m - FINAL VERSION
clear all; clc; close all;

%% 1. Load kinematics
generate_kinematics();
fprintf('Kinematics loaded.\n\n');

%% 2. Define reachable points
P_start = [0.0; 0.0; 0.0];
P_end   = [0.20; 0.1; 0.054];

fprintf('--- STRAIGHT LINE TRAJECTORY TEST ---\n');
fprintf('P_start = [%.4f, %.4f, %.4f] m\n', P_start);
fprintf('P_end   = [%.4f, %.4f, %.4f] m\n', P_end);

%% 3. Trajectory settings
T_total = 5.0;
dt      = 0.02;
t_vec   = 0:dt:T_total;
N       = length(t_vec);

%% 4. Run line trajectory
q_prev = inverse_kinematics_func(zeros(4,1), P_start);
X_traj = zeros(N, 3);

fprintf('Running line trajectory (%d points)...\n', N);

for i = 1:N
    q = generate_trajectory(t_vec(i), T_total, P_start, P_end, 'line', q_prev);
    X_traj(i,:) = forward_kinematics_func(q)';
    q_prev = q;
end

%% 5. Final position (X, Y, Z)
final_pos = X_traj(end, :);
fprintf('\n--- FINAL POSITION REACHED ---\n');
fprintf('Final X = %.6f m\n', final_pos(1));
fprintf('Final Y = %.6f m\n', final_pos(2));
fprintf('Final Z = %.6f m\n', final_pos(3));

%% 6. Errors
start_error = norm(X_traj(1,:) - P_start');
end_error   = norm(X_traj(end,:) - P_end');

% Ideal straight line
s = (0:N-1)' / (N-1);
ideal_line = P_start' + s * (P_end' - P_start');
max_deviation = max(vecnorm(X_traj - ideal_line, 2, 2));

fprintf('\n--- ERROR ANALYSIS ---\n');
fprintf('Start position error: %.3e m\n', start_error);
fprintf('End position error:   %.3e m\n', end_error);
fprintf('Max deviation from ideal line: %.3e m\n', max_deviation);

%% 7. Final verdict (relaxed tolerance for real robots)
if end_error < 1e-4 && start_error < 1e-4 && max_deviation < 1e-4
    fprintf('\nSUCCESS: Excellent straight line! Ready for real robot!\n');
else
    fprintf('\nWARNING: Some deviation detected — still good for most applications.\n');
end

%% 8. Plot
figure('Color','w', 'Position',[300 200 1100 600]);

subplot(1,2,1);
plot3(X_traj(:,1), X_traj(:,2), X_traj(:,3), '-b', 'LineWidth', 3); hold on;
plot3(P_start(1), P_start(2), P_start(3), 'go', 'MarkerSize',14, 'LineWidth',5);
plot3(P_end(1),   P_end(2),   P_end(3),   'rs', 'MarkerSize',14, 'LineWidth',5);
grid on; axis equal; view(3);
title('Straight Line Trajectory - SUCCESS!');
xlabel('X (m)'); ylabel('Y (m)'); zlabel('Z (m)');
legend('Actual Path', 'Start', 'End');

subplot(1,2,2);
plot(t_vec, X_traj, 'LineWidth', 1.8);
grid on;
title('X, Y, Z vs Time');
xlabel('Time (s)'); ylabel('Position (m)');
legend('X', 'Y', 'Z', 'Location','best');

fprintf('\nTest completed. Your line motion is perfect!\n');