% TEST SCRIPT for all kinematics functions

clear all;
clc;
close all;

%% 1. GENERATE THE NUMERICAL FUNCTIONS
generate_kinematics();


%% 2. DEFINE A TEST CONFIGURATION

q_original = [0; pi/2; pi/2; 0]; % (in radians)


%% 3. TEST 1: Forward Kinematics
fprintf('\n--- TEST 1: Forward Kinematics ---\n');
X_target = forward_kinematics_func(q_original);

fprintf('Original Joint Angles (q_original):\n');
disp(q_original');
fprintf('Resulting Position (X_target):\n');
disp(X_target');

%% 4. TEST 2: Inverse Kinematics (The "Round-Trip" Test)
fprintf('\n--- TEST 3: Inverse Kinematics (Round-Trip) ---\n');
% We will now try to find the joint angles 'q' that
% result in 'X_target', which we just calculated.

% We MUST start from a *different* initial guess.
% If q0 = q_original, the solver does no work.
q_initial_guess = [0; 0; 0; 0];
fprintf('Target Position is X_target:\n');
disp(X_target');
fprintf('Solving for q starting from an initial guess of all zeros...\n');

% Run the IK solver
q_solution = inverse_kinematics_func(q_initial_guess, X_target);


%% 5. VERIFY THE RESULTS
fprintf('\n--- TEST 4: Verification ---\n');
fprintf('Original q:    [%.4f, %.4f, %.4f, %.4f]\n', q_original);
fprintf('Solved q:      [%.4f, %.4f, %.4f, %.4f]\n', q_solution);


fprintf('\nChecking joint angle error (q_solution - q_original):\n');
q_error_vec = q_solution - q_original;
fprintf('Joint error norm: %.6f\n', norm(q_error_vec));
disp(q_error_vec');

% --- THE REAL TEST ---
% The REAL test is not if q == q_original.
% The REAL test is if the *position* from 'q_solution'
% matches the 'X_target'.

fprintf('\nVerifying position of the *solved* q:\n');
X_final = forward_kinematics_func(q_solution);
position_error_vec = X_final - X_target;
position_error_norm = norm(position_error_vec);

fprintf('Final position:   [%.6f, %.6f, %.6f]\n', X_final);
fprintf('Target position:  [%.6f, %.6f, %.6f]\n', X_target);
fprintf('Final Position Error Norm: %.10f\n', position_error_norm);

if position_error_norm < 1e-3 % (It should be < 1e-4 from the solver)
    fprintf('\nSUCCESS: The IK solver found a valid solution.\n');
else
    fprintf('\nFAILURE: The IK solver did not find a valid solution.\n');
end