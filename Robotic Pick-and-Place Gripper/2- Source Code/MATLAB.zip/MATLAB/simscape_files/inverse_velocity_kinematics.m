function q_dot = inverse_velocity_kinematics(q, V)

    Jinv = jacobian_inverse_numerical(q(:));
    q_dot = Jinv *V(:);

end