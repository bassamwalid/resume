% TEST SCRIPT for velocity kinematics functions

clear all;
clc;
close all;

%% 1. GENERATE THE NUMERICAL FUNCTIONS
generate_kinematics();


%% 2. DEFINE A TEST STATE

fprintf('\n--- Velocity Kinematics Test ---\n');

q = [0; 0; -0; 0]; % Current joint angles (rad)
q_dot_original = [0; pi/2; 0; 0]; % Original joint velocities (rad/s)

fprintf('Testing at q = [%.2f, %.2f, %.2f, %.2f]\n', q);
fprintf('Original q_dot = [%.2f, %.2f, %.2f, %.2f]\n', q_dot_original);


%% 3. TEST 1: Forward Velocity Kinematics
% Find the task-space velocity that results
% from our original joint velocities.
V_target = forward_velocity_kinematics(q, q_dot_original);

fprintf('Resulting V_target (x_dot, y_dot, z_dot) = [%.4f, %.4f, %.4f]\n', V_target);


%% 4. TEST 2: Inverse Velocity Kinematics
% Now, ask the inverse solver to find the joint velocities
% needed to achieve that V_target.
q_dot_solution = inverse_velocity_kinematics(q, V_target);

fprintf('\nSolved q_dot = [%.2f, %.2f, %.2f, %.2f]\n', q_dot_solution);


%% 5. VERIFY THE RESULTS
% --- IMPORTANT CHECK ---
% Just like the position solver, the robot is redundant.
% 'q_dot_solution' will NOT equal 'q_dot_original'.
%
% 'q_dot_solution' is the "minimum norm" solution, meaning it's
% the "smallest" vector that does the job. This is what pinv() does.
fprintf('Original q_dot norm: %.4f\n', norm(q_dot_original));
fprintf('Solved q_dot norm:   %.4f\n', norm(q_dot_solution));
fprintf('(Notice the solved norm is smaller or equal, as expected.)\n');


% --- THE REAL TEST ---
% The REAL test is to put 'q_dot_solution' back into the
% forward function. It should produce the correct 'V_target'.

fprintf('\nVerifying solution...\n');
V_check = forward_velocity_kinematics(q, q_dot_solution);

fprintf('Target V:     [%.6f, %.6f, %.6f]\n', V_target);
fprintf('Resulting V:  [%.6f, %.6f, %.6f]\n', V_check);

% Calculate the final error
velocity_error_norm = norm(V_target - V_check);
fprintf('Final Velocity Error Norm: %.10f\n', velocity_error_norm);

if velocity_error_norm < 1e-6
    fprintf('\nSUCCESS: The inverse velocity solver found a valid solution.\n');
else
    fprintf('\nFAILURE: The inverse velocity solver did not find a valid solution.\n');
end