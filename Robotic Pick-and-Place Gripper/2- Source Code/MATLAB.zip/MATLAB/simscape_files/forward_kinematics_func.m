function X = forward_kinematics_func(q)

    X = fk_numerical(q(:));
    X = double(X);      % ensure numeric

end