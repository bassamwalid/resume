function J_inv = jacobian_inverse_numerical(q)

J = jacobian_numerical(q);

J_inv = pinv(J);

end