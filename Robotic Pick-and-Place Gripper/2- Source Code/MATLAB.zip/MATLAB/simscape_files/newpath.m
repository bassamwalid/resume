model = 'x5_DOF_Robot_Assembly';

% New correct data file path
newPath = 'C:\Documents\MATLAB\simscape_files\x5_DOF_Robot_Assembly_DataFile.m';

% Load model
load_system(model);

% Get model workspace
ws = get_param(model, 'ModelWorkspace');

% Set the data source to the new file
ws.DataSource = 'MATLAB File';
ws.FileName   = newPath;

% Reload workspace
reload(ws);

% Save model
save_system(model);

disp('Data file path updated successfully.');
