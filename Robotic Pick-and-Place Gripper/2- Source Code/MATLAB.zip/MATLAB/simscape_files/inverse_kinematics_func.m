function q = inverse_kinematics_func(q0, X)

    q = q0(:);            % Set current q to the initial guess
    X = X(:);

    max_iterations = 500;   % ← ADD THIS LINE (or any number you like)

    for i = 1:max_iterations
        
        % A. Call the Forward Kinematics to get current pose
        X_current = forward_kinematics_func(q);
        
        % B. Define f (The error function)
        % f = Current_Position - Target_Position
        f = X_current - X;
        
        % C. Check convergence (Exit if error is small enough)
        current_error = norm(f);

        if current_error < 1e-4
            %fprintf('Converged in %d iterations. Final Error: %.5f\n', i, current_error);
            
            q = wrapToPi(q); 

            return;
        end
     
        % D. Get the Inverse Jacobian
        J_inv = jacobian_inverse_numerical(q);
        
        % E. Update q using Newton-Raphson formula
        % q_new = q_old - J_inv * f
        q = q - J_inv * f;
    end
    
    % 3. Fallback if not converged
    warning('Inverse kinematics did not converge within %d iterations.', max_iterations);

end