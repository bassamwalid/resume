//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// jacobian_numerical.h
//
// Code generation for function 'jacobian_numerical'
//

#ifndef JACOBIAN_NUMERICAL_H
#define JACOBIAN_NUMERICAL_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void jacobian_numerical(const double in1[4], double J_sym[12]);

#endif
// End of code generation (jacobian_numerical.h)
