//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// fk_numerical_types.h
//
// Code generation for function 'fk_numerical'
//

#ifndef FK_NUMERICAL_TYPES_H
#define FK_NUMERICAL_TYPES_H

// Include files
#include "rtwtypes.h"

#endif
// End of code generation (fk_numerical_types.h)
