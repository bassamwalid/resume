//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// generate_trajectory.h
//
// Code generation for function 'generate_trajectory'
//

#ifndef GENERATE_TRAJECTORY_H
#define GENERATE_TRAJECTORY_H

// Include files
#include "rtwtypes.h"
#include "string1.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void generate_trajectory(double t, double T_total,
                                const double P_start[3], const double P_end[3],
                                const coder::rtString *trajectory_type,
                                const double q_previous[4], double q_next[4]);

#endif
// End of code generation (generate_trajectory.h)
