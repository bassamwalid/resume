//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// strcmp.h
//
// Code generation for function 'strcmp'
//

#ifndef STRCMP_H
#define STRCMP_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace coder {
class rtString;

}

// Function Declarations
namespace coder {
namespace internal {
boolean_T b_strcmp(const rtString *a);

boolean_T b_strcmp(const array<char, 2U> &a);

boolean_T c_strcmp(const rtString *a);

boolean_T c_strcmp(const array<char, 2U> &a);

} // namespace internal
} // namespace coder

#endif
// End of code generation (strcmp.h)
