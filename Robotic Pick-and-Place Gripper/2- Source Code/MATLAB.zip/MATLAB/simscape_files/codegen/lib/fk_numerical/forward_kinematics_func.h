//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// forward_kinematics_func.h
//
// Code generation for function 'forward_kinematics_func'
//

#ifndef FORWARD_KINEMATICS_FUNC_H
#define FORWARD_KINEMATICS_FUNC_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void forward_kinematics_func(const double q[4], double X[3]);

#endif
// End of code generation (forward_kinematics_func.h)
