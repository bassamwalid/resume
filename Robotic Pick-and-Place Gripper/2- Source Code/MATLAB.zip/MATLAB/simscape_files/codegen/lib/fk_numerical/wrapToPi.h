//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// wrapToPi.h
//
// Code generation for function 'wrapToPi'
//

#ifndef WRAPTOPI_H
#define WRAPTOPI_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void wrapToPi(double lambda[4]);

}

#endif
// End of code generation (wrapToPi.h)
