//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_fk_numerical_api.cpp
//
// Code generation for function 'fk_numerical'
//

// Include files
#include "_coder_fk_numerical_api.h"
#include "_coder_fk_numerical_mex.h"
#include "coder_array_mex.h"

// Variable Definitions
emlrtCTX emlrtRootTLSGlobal{nullptr};

emlrtContext emlrtContextGlobal{
    true,                                                 // bFirstTime
    false,                                                // bInitialized
    131675U,                                              // fVersionInfo
    nullptr,                                              // fErrorFunction
    "fk_numerical",                                       // fFunctionName
    nullptr,                                              // fRTCallStack
    false,                                                // bDebugMode
    {2045744189U, 2170104910U, 2743257031U, 4284093946U}, // fSigWrd
    nullptr                                               // fSigMem
};

// Function Declarations
static void b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                               const emlrtMsgIdentifier *msgId,
                               coder::array<char_T, 2U> &ret);

static real_T (*b_emlrt_marshallIn(const emlrtStack &sp,
                                   const mxArray *b_nullptr,
                                   const char_T *identifier))[3];

static real_T (*b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                                   const emlrtMsgIdentifier *parentId))[3];

static const mxArray *b_emlrt_marshallOut(real_T u[12]);

static real_T c_emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                                 const char_T *identifier);

static real_T c_emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                                 const emlrtMsgIdentifier *parentId);

static const mxArray *c_emlrt_marshallOut(real_T u[4]);

static real_T (*d_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[4];

static real_T (*e_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[3];

static void emlrtExitTimeCleanupDtorFcn(const void *r);

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                             const char_T *identifier, rtString &y);

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                             const emlrtMsgIdentifier *parentId, rtString &y);

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                             const emlrtMsgIdentifier *parentId,
                             coder::array<char_T, 2U> &y);

static real_T (*emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                                 const char_T *identifier))[4];

static real_T (*emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                                 const emlrtMsgIdentifier *parentId))[4];

static const mxArray *emlrt_marshallOut(real_T u[3]);

static const mxArray *emlrt_marshallOut(coder::array<real_T, 2U> &u);

static real_T f_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                 const emlrtMsgIdentifier *msgId);

// Function Definitions
static real_T (*b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                                   const emlrtMsgIdentifier *parentId))[3]
{
  real_T(*y)[3];
  y = e_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T (*b_emlrt_marshallIn(const emlrtStack &sp,
                                   const mxArray *b_nullptr,
                                   const char_T *identifier))[3]
{
  emlrtMsgIdentifier thisId;
  real_T(*y)[3];
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = nullptr;
  thisId.bParentIsCell = false;
  y = b_emlrt_marshallIn(sp, emlrtAlias(b_nullptr), &thisId);
  emlrtDestroyArray(&b_nullptr);
  return y;
}

static void b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                               const emlrtMsgIdentifier *msgId,
                               coder::array<char_T, 2U> &ret)
{
  static const int32_T dims[2]{1, -1};
  int32_T iv[2];
  boolean_T bv[2]{false, true};
  emlrtCheckVsBuiltInR2012b((emlrtConstCTX)&sp, msgId, src, "char", false, 2U,
                            (const void *)&dims[0], &bv[0], &iv[0]);
  ret.set_size(iv[0], iv[1]);
  emlrtImportArrayR2015b((emlrtConstCTX)&sp, src, &ret[0], 1, false);
  emlrtDestroyArray(&src);
}

static const mxArray *b_emlrt_marshallOut(real_T u[12])
{
  static const int32_T iv[2]{0, 0};
  static const int32_T iv1[2]{3, 4};
  const mxArray *m;
  const mxArray *y;
  y = nullptr;
  m = emlrtCreateNumericArray(2, (const void *)&iv[0], mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m, &u[0]);
  emlrtSetDimensions((mxArray *)m, &iv1[0], 2);
  emlrtAssign(&y, m);
  return y;
}

static real_T c_emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                                 const emlrtMsgIdentifier *parentId)
{
  real_T y;
  y = f_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T c_emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                                 const char_T *identifier)
{
  emlrtMsgIdentifier thisId;
  real_T y;
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = nullptr;
  thisId.bParentIsCell = false;
  y = c_emlrt_marshallIn(sp, emlrtAlias(b_nullptr), &thisId);
  emlrtDestroyArray(&b_nullptr);
  return y;
}

static const mxArray *c_emlrt_marshallOut(real_T u[4])
{
  static const int32_T i{0};
  static const int32_T i1{4};
  const mxArray *m;
  const mxArray *y;
  y = nullptr;
  m = emlrtCreateNumericArray(1, (const void *)&i, mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m, &u[0]);
  emlrtSetDimensions((mxArray *)m, &i1, 1);
  emlrtAssign(&y, m);
  return y;
}

static real_T (*d_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[4]
{
  static const int32_T dims{4};
  real_T(*ret)[4];
  int32_T i;
  boolean_T b{false};
  emlrtCheckVsBuiltInR2012b((emlrtConstCTX)&sp, msgId, src, "double", false, 1U,
                            (const void *)&dims, &b, &i);
  ret = (real_T(*)[4])emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static real_T (*e_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[3]
{
  static const int32_T dims{3};
  real_T(*ret)[3];
  int32_T i;
  boolean_T b{false};
  emlrtCheckVsBuiltInR2012b((emlrtConstCTX)&sp, msgId, src, "double", false, 1U,
                            (const void *)&dims, &b, &i);
  ret = (real_T(*)[3])emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static void emlrtExitTimeCleanupDtorFcn(const void *r)
{
  emlrtExitTimeCleanup(&emlrtContextGlobal);
}

static real_T (*emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                                 const emlrtMsgIdentifier *parentId))[4]
{
  real_T(*y)[4];
  y = d_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T (*emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                                 const char_T *identifier))[4]
{
  emlrtMsgIdentifier thisId;
  real_T(*y)[4];
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = nullptr;
  thisId.bParentIsCell = false;
  y = emlrt_marshallIn(sp, emlrtAlias(b_nullptr), &thisId);
  emlrtDestroyArray(&b_nullptr);
  return y;
}

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                             const emlrtMsgIdentifier *parentId,
                             coder::array<char_T, 2U> &y)
{
  b_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                             const emlrtMsgIdentifier *parentId, rtString &y)
{
  emlrtMsgIdentifier thisId;
  const mxArray *propValues;
  const char_T *propClasses{"coder.internal.string"};
  const char_T *propNames{"Value"};
  propValues = nullptr;
  thisId.fParent = parentId;
  thisId.bParentIsCell = false;
  emlrtCheckMcosClass2017a((emlrtCTX)&sp, parentId, u, "string");
  emlrtAssign(&u, emlrtConvertInstanceToRedirectTarget(
                      (emlrtCTX)&sp, u, 0, "coder.internal.string"));
  emlrtCheckMcosClass2017a((emlrtCTX)&sp, parentId, u, "coder.internal.string");
  emlrtGetAllProperties((emlrtCTX)&sp, u, 0, 1, (const char_T **)&propNames,
                        (const char_T **)&propClasses, &propValues);
  thisId.fIdentifier = "Value";
  emlrt_marshallIn(sp, emlrtAlias(propValues), &thisId, y.Value);
  emlrtDestroyArrays(1, &propValues);
  emlrtDestroyArray(&u);
}

static void emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                             const char_T *identifier, rtString &y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = nullptr;
  thisId.bParentIsCell = false;
  emlrt_marshallIn(sp, emlrtAlias(b_nullptr), &thisId, y);
  emlrtDestroyArray(&b_nullptr);
}

static const mxArray *emlrt_marshallOut(real_T u[3])
{
  static const int32_T i{0};
  static const int32_T i1{3};
  const mxArray *m;
  const mxArray *y;
  y = nullptr;
  m = emlrtCreateNumericArray(1, (const void *)&i, mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m, &u[0]);
  emlrtSetDimensions((mxArray *)m, &i1, 1);
  emlrtAssign(&y, m);
  return y;
}

static const mxArray *emlrt_marshallOut(coder::array<real_T, 2U> &u)
{
  static const int32_T iv[2]{0, 0};
  const mxArray *m;
  const mxArray *y;
  y = nullptr;
  m = emlrtCreateNumericArray(2, (const void *)&iv[0], mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m, &u[0]);
  emlrtSetDimensions((mxArray *)m, u.size(), 2);
  u.set_owner(false);
  emlrtAssign(&y, m);
  return y;
}

static real_T f_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                 const emlrtMsgIdentifier *msgId)
{
  static const int32_T dims{0};
  real_T ret;
  emlrtCheckBuiltInR2012b((emlrtConstCTX)&sp, msgId, src, "double", false, 0U,
                          (const void *)&dims);
  ret = *static_cast<real_T *>(emlrtMxGetData(src));
  emlrtDestroyArray(&src);
  return ret;
}

void fk_numerical_api(const mxArray *prhs, const mxArray **plhs)
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  real_T(*in1)[4];
  real_T(*X_sym)[3];
  st.tls = emlrtRootTLSGlobal;
  X_sym = (real_T(*)[3])mxMalloc(sizeof(real_T[3]));
  // Marshall function inputs
  in1 = emlrt_marshallIn(st, emlrtAlias(prhs), "in1");
  // Invoke the target function
  fk_numerical(*in1, *X_sym);
  // Marshall function outputs
  *plhs = emlrt_marshallOut(*X_sym);
}

void fk_numerical_atexit()
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtPushHeapReferenceStackR2021a(&st, false, nullptr,
                                    (void *)&emlrtExitTimeCleanupDtorFcn,
                                    nullptr, nullptr, nullptr);
  emlrtEnterRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
  fk_numerical_xil_terminate();
  fk_numerical_xil_shutdown();
  emlrtExitTimeCleanup(&emlrtContextGlobal);
}

void fk_numerical_initialize()
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtClearAllocCountR2012b(&st, false, 0U, nullptr);
  emlrtEnterRtStackR2012b(&st);
  emlrtFirstTimeR2012b(emlrtRootTLSGlobal);
}

void fk_numerical_terminate()
{
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

void forward_kinematics_func_api(const mxArray *prhs, const mxArray **plhs)
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  real_T(*q)[4];
  real_T(*X)[3];
  st.tls = emlrtRootTLSGlobal;
  X = (real_T(*)[3])mxMalloc(sizeof(real_T[3]));
  // Marshall function inputs
  q = emlrt_marshallIn(st, emlrtAlias(prhs), "q");
  // Invoke the target function
  forward_kinematics_func(*q, *X);
  // Marshall function outputs
  *plhs = emlrt_marshallOut(*X);
}

void forward_velocity_kinematics_api(const mxArray *const prhs[2],
                                     const mxArray **plhs)
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  real_T(*q)[4];
  real_T(*q_dot)[4];
  real_T(*V)[3];
  st.tls = emlrtRootTLSGlobal;
  V = (real_T(*)[3])mxMalloc(sizeof(real_T[3]));
  // Marshall function inputs
  q = emlrt_marshallIn(st, emlrtAlias(prhs[0]), "q");
  q_dot = emlrt_marshallIn(st, emlrtAlias(prhs[1]), "q_dot");
  // Invoke the target function
  forward_velocity_kinematics(*q, *q_dot, *V);
  // Marshall function outputs
  *plhs = emlrt_marshallOut(*V);
}

void generate_full_trajectory_api(const mxArray *const prhs[6], int32_T nlhs,
                                  const mxArray *plhs[2])
{
  coder::array<real_T, 2U> q_traj;
  coder::array<real_T, 2U> t_vec;
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  const mxArray *prhs_copy_idx_0;
  const mxArray *prhs_copy_idx_1;
  const mxArray *prhs_copy_idx_2;
  rtString trajectory_type;
  real_T(*q)[4];
  real_T(*P_end)[3];
  real_T(*P_start)[3];
  real_T T_total;
  real_T dt;
  st.tls = emlrtRootTLSGlobal;
  emlrtHeapReferenceStackEnterFcnR2012b(&st);
  prhs_copy_idx_0 = emlrtProtectR2012b(prhs[0], 0, false, -1);
  prhs_copy_idx_1 = emlrtProtectR2012b(prhs[1], 1, false, -1);
  prhs_copy_idx_2 = emlrtProtectR2012b(prhs[2], 2, false, -1);
  // Marshall function inputs
  P_start = b_emlrt_marshallIn(st, emlrtAlias(prhs_copy_idx_0), "P_start");
  P_end = b_emlrt_marshallIn(st, emlrtAlias(prhs_copy_idx_1), "P_end");
  q = emlrt_marshallIn(st, emlrtAlias(prhs_copy_idx_2), "q");
  emlrt_marshallIn(st, emlrtAliasP(prhs[3]), "trajectory_type",
                   trajectory_type);
  T_total = c_emlrt_marshallIn(st, emlrtAliasP(prhs[4]), "T_total");
  dt = c_emlrt_marshallIn(st, emlrtAliasP(prhs[5]), "dt");
  // Invoke the target function
  generate_full_trajectory(*P_start, *P_end, *q, &trajectory_type, T_total, dt,
                           t_vec, q_traj);
  // Marshall function outputs
  t_vec.set_owner(false);
  plhs[0] = emlrt_marshallOut(t_vec);
  if (nlhs > 1) {
    q_traj.set_owner(false);
    plhs[1] = emlrt_marshallOut(q_traj);
  }
  emlrtHeapReferenceStackLeaveFcnR2012b(&st);
}

void generate_trajectory_api(const mxArray *const prhs[6], const mxArray **plhs)
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  rtString trajectory_type;
  real_T(*q_next)[4];
  real_T(*q_previous)[4];
  real_T(*P_end)[3];
  real_T(*P_start)[3];
  real_T T_total;
  real_T t;
  st.tls = emlrtRootTLSGlobal;
  q_next = (real_T(*)[4])mxMalloc(sizeof(real_T[4]));
  emlrtHeapReferenceStackEnterFcnR2012b(&st);
  // Marshall function inputs
  t = c_emlrt_marshallIn(st, emlrtAliasP(prhs[0]), "t");
  T_total = c_emlrt_marshallIn(st, emlrtAliasP(prhs[1]), "T_total");
  P_start = b_emlrt_marshallIn(st, emlrtAlias(prhs[2]), "P_start");
  P_end = b_emlrt_marshallIn(st, emlrtAlias(prhs[3]), "P_end");
  emlrt_marshallIn(st, emlrtAliasP(prhs[4]), "trajectory_type",
                   trajectory_type);
  q_previous = emlrt_marshallIn(st, emlrtAlias(prhs[5]), "q_previous");
  // Invoke the target function
  generate_trajectory(t, T_total, *P_start, *P_end, &trajectory_type,
                      *q_previous, *q_next);
  // Marshall function outputs
  *plhs = c_emlrt_marshallOut(*q_next);
  emlrtHeapReferenceStackLeaveFcnR2012b(&st);
}

void inverse_kinematics_func_api(const mxArray *const prhs[2],
                                 const mxArray **plhs)
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  const mxArray *prhs_copy_idx_1;
  real_T(*q)[4];
  real_T(*q0)[4];
  real_T(*X)[3];
  st.tls = emlrtRootTLSGlobal;
  q = (real_T(*)[4])mxMalloc(sizeof(real_T[4]));
  prhs_copy_idx_1 = emlrtProtectR2012b(prhs[1], 1, false, -1);
  // Marshall function inputs
  q0 = emlrt_marshallIn(st, emlrtAlias(prhs[0]), "q0");
  X = b_emlrt_marshallIn(st, emlrtAlias(prhs_copy_idx_1), "X");
  // Invoke the target function
  inverse_kinematics_func(*q0, *X, *q);
  // Marshall function outputs
  *plhs = c_emlrt_marshallOut(*q);
}

void inverse_velocity_kinematics_api(const mxArray *const prhs[2],
                                     const mxArray **plhs)
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  real_T(*q)[4];
  real_T(*q_dot)[4];
  real_T(*V)[3];
  st.tls = emlrtRootTLSGlobal;
  q_dot = (real_T(*)[4])mxMalloc(sizeof(real_T[4]));
  // Marshall function inputs
  q = emlrt_marshallIn(st, emlrtAlias(prhs[0]), "q");
  V = b_emlrt_marshallIn(st, emlrtAlias(prhs[1]), "V");
  // Invoke the target function
  inverse_velocity_kinematics(*q, *V, *q_dot);
  // Marshall function outputs
  *plhs = c_emlrt_marshallOut(*q_dot);
}

void jacobian_numerical_api(const mxArray *prhs, const mxArray **plhs)
{
  emlrtStack st{
      nullptr, // site
      nullptr, // tls
      nullptr  // prev
  };
  real_T(*J_sym)[12];
  real_T(*in1)[4];
  st.tls = emlrtRootTLSGlobal;
  J_sym = (real_T(*)[12])mxMalloc(sizeof(real_T[12]));
  // Marshall function inputs
  in1 = emlrt_marshallIn(st, emlrtAlias(prhs), "in1");
  // Invoke the target function
  jacobian_numerical(*in1, *J_sym);
  // Marshall function outputs
  *plhs = b_emlrt_marshallOut(*J_sym);
}

// End of code generation (_coder_fk_numerical_api.cpp)
