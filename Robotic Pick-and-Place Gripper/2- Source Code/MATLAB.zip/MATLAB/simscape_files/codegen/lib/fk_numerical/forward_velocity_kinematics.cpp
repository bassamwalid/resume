//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// forward_velocity_kinematics.cpp
//
// Code generation for function 'forward_velocity_kinematics'
//

// Include files
#include "forward_velocity_kinematics.h"
#include "jacobian_numerical.h"
#include "rt_nonfinite.h"
#include <cstring>
#include <emmintrin.h>

// Function Definitions
void forward_velocity_kinematics(const double q[4], const double q_dot[4],
                                 double V[3])
{
  __m128d r;
  __m128d r1;
  double J[12];
  jacobian_numerical(q, J);
  std::memset(&V[0], 0, 3U * sizeof(double));
  r = _mm_loadu_pd(&J[0]);
  r1 = _mm_loadu_pd(&V[0]);
  _mm_storeu_pd(&V[0], _mm_add_pd(r1, _mm_mul_pd(r, _mm_set1_pd(q_dot[0]))));
  V[2] += q_dot[0] * J[2];
  r = _mm_loadu_pd(&J[3]);
  r1 = _mm_loadu_pd(&V[0]);
  _mm_storeu_pd(&V[0], _mm_add_pd(r1, _mm_mul_pd(r, _mm_set1_pd(q_dot[1]))));
  V[2] += q_dot[1] * J[5];
  r = _mm_loadu_pd(&J[6]);
  r1 = _mm_loadu_pd(&V[0]);
  _mm_storeu_pd(&V[0], _mm_add_pd(r1, _mm_mul_pd(r, _mm_set1_pd(q_dot[2]))));
  V[2] += q_dot[2] * J[8];
  r = _mm_loadu_pd(&J[9]);
  r1 = _mm_loadu_pd(&V[0]);
  _mm_storeu_pd(&V[0], _mm_add_pd(r1, _mm_mul_pd(r, _mm_set1_pd(q_dot[3]))));
  V[2] += q_dot[3] * J[11];
}

// End of code generation (forward_velocity_kinematics.cpp)
