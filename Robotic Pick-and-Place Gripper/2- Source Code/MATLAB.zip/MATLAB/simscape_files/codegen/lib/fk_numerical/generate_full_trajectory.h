//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// generate_full_trajectory.h
//
// Code generation for function 'generate_full_trajectory'
//

#ifndef GENERATE_FULL_TRAJECTORY_H
#define GENERATE_FULL_TRAJECTORY_H

// Include files
#include "rtwtypes.h"
#include "string1.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void generate_full_trajectory(const double P_start[3],
                                     const double P_end[3], double q[4],
                                     const coder::rtString *trajectory_type,
                                     double T_total, double dt,
                                     coder::array<double, 2U> &t_vec,
                                     coder::array<double, 2U> &q_traj);

#endif
// End of code generation (generate_full_trajectory.h)
