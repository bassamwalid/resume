//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// inverse_kinematics_func.cpp
//
// Code generation for function 'inverse_kinematics_func'
//

// Include files
#include "inverse_kinematics_func.h"
#include "forward_kinematics_func.h"
#include "jacobian_numerical.h"
#include "norm.h"
#include "pinv.h"
#include "rt_nonfinite.h"
#include "wrapToPi.h"
#include <emmintrin.h>

// Function Definitions
void inverse_kinematics_func(const double q0[4], const double X[3], double q[4])
{
  double dv[12];
  double X_current[3];
  int i;
  q[0] = q0[0];
  q[1] = q0[1];
  q[2] = q0[2];
  q[3] = q0[3];
  //  Set current q to the initial guess
  //  ← ADD THIS LINE (or any number you like)
  i = 0;
  int exitg1;
  do {
    exitg1 = 0;
    if (i < 500) {
      __m128d r;
      //  A. Call the Forward Kinematics to get current pose
      forward_kinematics_func(q, X_current);
      //  B. Define f (The error function)
      //  f = Current_Position - Target_Position
      r = _mm_loadu_pd(&X_current[0]);
      _mm_storeu_pd(&X_current[0], _mm_sub_pd(r, _mm_loadu_pd(&X[0])));
      X_current[2] -= X[2];
      //  C. Check convergence (Exit if error is small enough)
      if (coder::b_norm(X_current) < 0.0001) {
        // fprintf('Converged in %d iterations. Final Error: %.5f\n', i,
        // current_error);
        coder::wrapToPi(q);
        exitg1 = 1;
      } else {
        double J[12];
        double d;
        double d1;
        double d2;
        //  D. Get the Inverse Jacobian
        jacobian_numerical(q, J);
        //  E. Update q using Newton-Raphson formula
        //  q_new = q_old - J_inv * f
        coder::pinv(J, dv);
        d = X_current[0];
        d1 = X_current[1];
        d2 = X_current[2];
        for (int b_i{0}; b_i <= 2; b_i += 2) {
          __m128d r1;
          r = _mm_loadu_pd(&dv[b_i]);
          r1 = _mm_mul_pd(r, _mm_set1_pd(d));
          r = _mm_loadu_pd(&dv[b_i + 4]);
          r = _mm_mul_pd(r, _mm_set1_pd(d1));
          r1 = _mm_add_pd(r1, r);
          r = _mm_loadu_pd(&dv[b_i + 8]);
          r = _mm_mul_pd(r, _mm_set1_pd(d2));
          r = _mm_add_pd(r1, r);
          r1 = _mm_loadu_pd(&q[b_i]);
          r = _mm_sub_pd(r1, r);
          _mm_storeu_pd(&q[b_i], r);
        }
        i++;
      }
    } else {
      //  3. Fallback if not converged
      exitg1 = 1;
    }
  } while (exitg1 == 0);
}

// End of code generation (inverse_kinematics_func.cpp)
