//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// fk_numerical_data.h
//
// Code generation for function 'fk_numerical_data'
//

#ifndef FK_NUMERICAL_DATA_H
#define FK_NUMERICAL_DATA_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
// End of code generation (fk_numerical_data.h)
