//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// generate_full_trajectory.cpp
//
// Code generation for function 'generate_full_trajectory'
//

// Include files
#include "generate_full_trajectory.h"
#include "atan2.h"
#include "colon.h"
#include "dot.h"
#include "forward_kinematics_func.h"
#include "jacobian_numerical.h"
#include "mod.h"
#include "norm.h"
#include "pinv.h"
#include "rt_nonfinite.h"
#include "strcmp.h"
#include "string1.h"
#include "wrapToPi.h"
#include "coder_array.h"
#include <cmath>
#include <cstdio>
#include <emmintrin.h>

// Function Definitions
void generate_full_trajectory(const double P_start[3], const double P_end[3],
                              double q[4],
                              const coder::rtString *trajectory_type,
                              double T_total, double dt,
                              coder::array<double, 2U> &t_vec,
                              coder::array<double, 2U> &q_traj)
{
  __m128d r;
  __m128d r1;
  double J[12];
  double dv[12];
  double q_prev[4];
  double X_current[3];
  double X_target[3];
  double dir_xy[2];
  double mid_xy[2];
  double perp[2];
  double d;
  double r0;
  double r_t;
  int exitg1;
  int i;
  int scalarLB;
  //  GENERATE_FULL_TRAJECTORY
  //  Generates the COMPLETE joint trajectory from start to end
  //  Outputs:
  //    t_vec   : time vector [s] (1×N)
  //    q_traj  : joint angles [rad] (N×4) → ready to export to Simscape, CSV,
  //    Excel, etc.
  //
  //  Usage example:
  //    [t, q] = generate_full_trajectory([0.5;0;0.4], [0.5;0.15;0.4], 'circle',
  //    8, 0.02); plot(t, q);  % or save to file
  //  default 50 Hz
  if (std::isnan(dt) || std::isnan(T_total)) {
    t_vec.set_size(1, 1);
    t_vec[0] = rtNaN;
  } else if ((dt == 0.0) || ((T_total > 0.0) && (dt < 0.0)) ||
             ((T_total < 0.0) && (dt > 0.0))) {
    t_vec.set_size(1, 0);
  } else if (std::isinf(T_total) && std::isinf(dt)) {
    t_vec.set_size(1, 1);
    t_vec[0] = rtNaN;
  } else if (std::isinf(dt)) {
    t_vec.set_size(1, 1);
    t_vec[0] = 0.0;
  } else if (std::floor(dt) == dt) {
    int vectorUB;
    i = static_cast<int>(T_total / dt);
    t_vec.set_size(1, i + 1);
    scalarLB = ((i + 1) / 2) << 1;
    vectorUB = scalarLB - 2;
    for (int b_i{0}; b_i <= vectorUB; b_i += 2) {
      dir_xy[0] = b_i;
      dir_xy[1] = b_i + 1;
      r = _mm_loadu_pd(&dir_xy[0]);
      _mm_storeu_pd(&t_vec[b_i], _mm_mul_pd(_mm_set1_pd(dt), r));
    }
    for (int b_i{scalarLB}; b_i <= i; b_i++) {
      t_vec[b_i] = dt * static_cast<double>(b_i);
    }
  } else {
    coder::eml_float_colon(dt, T_total, t_vec);
  }
  scalarLB = t_vec.size(1);
  q_traj.set_size(t_vec.size(1), 4);
  q_prev[0] = 0.0;
  q_prev[1] = 0.0;
  q_prev[2] = 0.0;
  q_prev[3] = 0.0;
  //  Set current q to the initial guess
  //  ← ADD THIS LINE (or any number you like)
  i = 0;
  do {
    exitg1 = 0;
    if (i < 500) {
      //  A. Call the Forward Kinematics to get current pose
      forward_kinematics_func(q_prev, X_current);
      //  B. Define f (The error function)
      //  f = Current_Position - Target_Position
      r = _mm_loadu_pd(&X_current[0]);
      _mm_storeu_pd(&X_current[0], _mm_sub_pd(r, _mm_loadu_pd(&P_start[0])));
      X_current[2] -= P_start[2];
      //  C. Check convergence (Exit if error is small enough)
      if (coder::b_norm(X_current) < 0.0001) {
        // fprintf('Converged in %d iterations. Final Error: %.5f\n', i,
        // current_error);
        coder::wrapToPi(q_prev);
        exitg1 = 1;
      } else {
        //  D. Get the Inverse Jacobian
        jacobian_numerical(q_prev, J);
        //  E. Update q using Newton-Raphson formula
        //  q_new = q_old - J_inv * f
        coder::pinv(J, dv);
        r0 = X_current[0];
        r_t = X_current[1];
        d = X_current[2];
        for (int b_i{0}; b_i <= 2; b_i += 2) {
          r = _mm_loadu_pd(&dv[b_i]);
          r1 = _mm_mul_pd(r, _mm_set1_pd(r0));
          r = _mm_loadu_pd(&dv[b_i + 4]);
          r = _mm_mul_pd(r, _mm_set1_pd(r_t));
          r1 = _mm_add_pd(r1, r);
          r = _mm_loadu_pd(&dv[b_i + 8]);
          r = _mm_mul_pd(r, _mm_set1_pd(d));
          r = _mm_add_pd(r1, r);
          r1 = _mm_loadu_pd(&q_prev[b_i]);
          r = _mm_sub_pd(r1, r);
          _mm_storeu_pd(&q_prev[b_i], r);
        }
        i++;
      }
    } else {
      //  3. Fallback if not converged
      exitg1 = 1;
    }
  } while (exitg1 == 0);
  // fprintf('Generating %s trajectory: %.1f seconds, %d points...\n',
  // upper(trajectory_type), T_total, N);
  //  Main loop — generate all q values
  for (int b_i{0}; b_i < scalarLB; b_i++) {
    if (b_i == 0) {
      q_prev[0] = q[0];
      q_prev[1] = q[1];
      q_prev[2] = q[2];
      q_prev[3] = q[3];
    }
    //  GENERATE_TRAJECTORY
    //  Generates joint angles q for a given time t during a straight line or
    //  circular motion in 3D Cartesian space. Uses constant velocity (no
    //  acceleration profile). Input normalization Force start position as 3x1
    //  column vector [x;y;z] Force end position as 3x1 column vector [x;y;z]
    //  Use previous joint solution as initial guess for IK (very important!)
    //  Trajectory type selection
    if (coder::internal::b_strcmp(trajectory_type->Value)) {
      //  ====================== STRAIGHT LINE MOTION =========================
      r0 = t_vec[b_i];
      r = _mm_loadu_pd(&P_start[0]);
      _mm_storeu_pd(
          &X_target[0],
          _mm_add_pd(
              r, _mm_mul_pd(_mm_div_pd(_mm_sub_pd(_mm_loadu_pd(&P_end[0]), r),
                                       _mm_set1_pd(T_total)),
                            _mm_set1_pd(r0))));
      X_target[2] = P_start[2] + (P_end[2] - P_start[2]) / T_total * r0;
    } else if (coder::internal::c_strcmp(trajectory_type->Value)) {
      //  ====================== CIRCULAR (HALF CIRCLE) MOTION =================
      //  Center of the circle (midpoint between start and end)
      r = _mm_loadu_pd(&P_start[0]);
      r1 = _mm_loadu_pd(&P_end[0]);
      _mm_storeu_pd(&mid_xy[0],
                    _mm_div_pd(_mm_add_pd(r, r1), _mm_set1_pd(2.0)));
      _mm_storeu_pd(&dir_xy[0], _mm_sub_pd(r1, r));
      perp[0] = -dir_xy[1];
      perp[1] = dir_xy[0];
      r = _mm_loadu_pd(&perp[0]);
      _mm_storeu_pd(&perp[0], _mm_div_pd(r, _mm_set1_pd(coder::c_norm(perp))));
      r = _mm_loadu_pd(&mid_xy[0]);
      _mm_storeu_pd(&dir_xy[0], _mm_sub_pd(_mm_loadu_pd(&P_start[0]), r));
      r0 = coder::dot(dir_xy, perp);
      //  calcualtions for X & Y
      r = _mm_loadu_pd(&perp[0]);
      r1 = _mm_loadu_pd(&mid_xy[0]);
      r = _mm_add_pd(r1, _mm_mul_pd(_mm_set1_pd(r0), r));
      _mm_storeu_pd(&mid_xy[0], r);
      _mm_storeu_pd(&dir_xy[0], _mm_sub_pd(_mm_loadu_pd(&P_start[0]), r));
      r0 = coder::c_norm(dir_xy);
      //  initial radius
      //  final radius
      r = _mm_loadu_pd(&mid_xy[0]);
      _mm_storeu_pd(&dir_xy[0], _mm_sub_pd(_mm_loadu_pd(&P_end[0]), r));
      d = t_vec[b_i];
      r_t = r0 + (coder::c_norm(dir_xy) - r0) / T_total * d;
      //  current radius
      if (r_t < 0.005) {
        r_t = 0.005;
      }
      // calculating angle theta
      r0 = coder::b_atan2(P_start[1] - mid_xy[1], P_start[0] - mid_xy[0]);
      //  initial angle
      //  final angle
      r0 += (coder::internal::scalar::b_mod(
                 (coder::b_atan2(P_end[1] - mid_xy[1], P_end[0] - mid_xy[0]) -
                  r0) +
                 3.1415926535897931) -
             3.1415926535897931) /
            T_total * d;
      //  current angle (this is the key!)
      //  calculations for Z
      //  Z velocity
      // final equation
      X_target[0] = mid_xy[0] + r_t * std::cos(r0);
      X_target[1] = mid_xy[1] + r_t * std::sin(r0);
      X_target[2] = P_start[2] + (P_end[2] - P_start[2]) / T_total * d;
    }
    //  ----- Inverse Kinematics
    //  --------------------------------------------------- Solve IK using the
    //  previous joint angles as initial guess This ensures continuity and fast
    //  convergence → smooth robot motion!
    q[0] = q_prev[0];
    q[1] = q_prev[1];
    q[2] = q_prev[2];
    q[3] = q_prev[3];
    //  Set current q to the initial guess
    //  ← ADD THIS LINE (or any number you like)
    i = 0;
    do {
      exitg1 = 0;
      if (i < 500) {
        //  A. Call the Forward Kinematics to get current pose
        forward_kinematics_func(q, X_current);
        //  B. Define f (The error function)
        //  f = Current_Position - Target_Position
        r = _mm_loadu_pd(&X_current[0]);
        r1 = _mm_loadu_pd(&X_target[0]);
        _mm_storeu_pd(&X_current[0], _mm_sub_pd(r, r1));
        X_current[2] -= X_target[2];
        //  C. Check convergence (Exit if error is small enough)
        if (coder::b_norm(X_current) < 0.0001) {
          // fprintf('Converged in %d iterations. Final Error: %.5f\n', i,
          // current_error);
          coder::wrapToPi(q);
          exitg1 = 1;
        } else {
          //  D. Get the Inverse Jacobian
          jacobian_numerical(q, J);
          //  E. Update q using Newton-Raphson formula
          //  q_new = q_old - J_inv * f
          coder::pinv(J, dv);
          r0 = X_current[0];
          r_t = X_current[1];
          d = X_current[2];
          for (int c_i{0}; c_i <= 2; c_i += 2) {
            r = _mm_loadu_pd(&dv[c_i]);
            r1 = _mm_mul_pd(r, _mm_set1_pd(r0));
            r = _mm_loadu_pd(&dv[c_i + 4]);
            r = _mm_mul_pd(r, _mm_set1_pd(r_t));
            r1 = _mm_add_pd(r1, r);
            r = _mm_loadu_pd(&dv[c_i + 8]);
            r = _mm_mul_pd(r, _mm_set1_pd(d));
            r = _mm_add_pd(r1, r);
            r1 = _mm_loadu_pd(&q[c_i]);
            r = _mm_sub_pd(r1, r);
            _mm_storeu_pd(&q[c_i], r);
          }
          i++;
        }
      } else {
        //  3. Fallback if not converged
        exitg1 = 1;
      }
    } while (exitg1 == 0);
    //  store as row
    q_traj[b_i] = q[0];
    q_prev[0] = q[0];
    q_traj[b_i + q_traj.size(0)] = q[1];
    q_prev[1] = q[1];
    q_traj[b_i + q_traj.size(0) * 2] = q[2];
    q_prev[2] = q[2];
    q_traj[b_i + q_traj.size(0) * 3] = q[3];
    q_prev[3] = q[3];
    //  continuity for next step
  }
  //  Final verification
  q_prev[0] = q_traj[q_traj.size(0) - 1];
  q_prev[1] = q_traj[(q_traj.size(0) + q_traj.size(0)) - 1];
  q_prev[2] = q_traj[(q_traj.size(0) + q_traj.size(0) * 2) - 1];
  q_prev[3] = q_traj[(q_traj.size(0) + q_traj.size(0) * 3) - 1];
  forward_kinematics_func(q_prev, X_current);
  std::printf("Trajectory complete!\n");
  std::fflush(stdout);
  // fprintf('Desired Position: [ %.4f, %.4f, %.4f ]\n', P_end);
  // fprintf('Actual Position: [ %.4f, %.4f, %.4f ]\n', X_final);
  // fprintf('Final position error: %.3e m\n', end_error);
  r = _mm_loadu_pd(&X_current[0]);
  _mm_storeu_pd(&X_current[0], _mm_sub_pd(r, _mm_loadu_pd(&P_end[0])));
  X_current[2] -= P_end[2];
  if (coder::b_norm(X_current) < 0.0001) {
    std::printf("SUCCESS: Trajectory is perfect \x97 ready for Simscape!\n");
    std::fflush(stdout);
  } else {
    std::printf("WARNING: Some error \x97 check workspace.\n");
    std::fflush(stdout);
  }
}

// End of code generation (generate_full_trajectory.cpp)
