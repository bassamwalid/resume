//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// forward_velocity_kinematics.h
//
// Code generation for function 'forward_velocity_kinematics'
//

#ifndef FORWARD_VELOCITY_KINEMATICS_H
#define FORWARD_VELOCITY_KINEMATICS_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void forward_velocity_kinematics(const double q[4],
                                        const double q_dot[4], double V[3]);

#endif
// End of code generation (forward_velocity_kinematics.h)
