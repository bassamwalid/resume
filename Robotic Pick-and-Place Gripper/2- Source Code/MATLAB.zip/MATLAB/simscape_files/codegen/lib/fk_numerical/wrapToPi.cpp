//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// wrapToPi.cpp
//
// Code generation for function 'wrapToPi'
//

// Include files
#include "wrapToPi.h"
#include "rt_nonfinite.h"
#include <cmath>

// Function Definitions
namespace coder {
void wrapToPi(double lambda[4])
{
  double b_tmp_data[4];
  double b_q;
  double q;
  int partialTrueCount;
  int trueCount;
  signed char tmp_data[4];
  boolean_T b;
  boolean_T b1;
  boolean_T b2;
  boolean_T b3;
  trueCount = 0;
  q = lambda[0];
  b = ((q < -3.1415926535897931) || (q > 3.1415926535897931));
  if (b) {
    trueCount = 1;
  }
  q = lambda[1];
  b1 = ((q < -3.1415926535897931) || (q > 3.1415926535897931));
  if (b1) {
    trueCount++;
  }
  q = lambda[2];
  b2 = ((q < -3.1415926535897931) || (q > 3.1415926535897931));
  if (b2) {
    trueCount++;
  }
  q = lambda[3];
  b3 = ((q < -3.1415926535897931) || (q > 3.1415926535897931));
  if (b3) {
    trueCount++;
  }
  partialTrueCount = 0;
  if (b) {
    tmp_data[0] = 0;
    partialTrueCount = 1;
  }
  if (b1) {
    tmp_data[partialTrueCount] = 1;
    partialTrueCount++;
  }
  if (b2) {
    tmp_data[partialTrueCount] = 2;
    partialTrueCount++;
  }
  if (b3) {
    tmp_data[partialTrueCount] = 3;
  }
  partialTrueCount = 0;
  if (b) {
    q = lambda[0] + 3.1415926535897931;
    if (std::isnan(q) || std::isinf(q)) {
      q = rtNaN;
    } else {
      b_q = std::abs(q / 6.2831853071795862);
      if (std::abs(b_q - std::floor(b_q + 0.5)) >
          2.2204460492503131E-16 * b_q) {
        q = std::fmod(q, 6.2831853071795862);
      } else {
        q = 0.0;
      }
      if (q == 0.0) {
        q = 0.0;
      } else if (q < 0.0) {
        q += 6.2831853071795862;
      }
    }
    b_tmp_data[0] = q;
    partialTrueCount = 1;
  }
  if (b1) {
    q = lambda[1] + 3.1415926535897931;
    if (std::isnan(q) || std::isinf(q)) {
      q = rtNaN;
    } else {
      b_q = std::abs(q / 6.2831853071795862);
      if (std::abs(b_q - std::floor(b_q + 0.5)) >
          2.2204460492503131E-16 * b_q) {
        q = std::fmod(q, 6.2831853071795862);
      } else {
        q = 0.0;
      }
      if (q == 0.0) {
        q = 0.0;
      } else if (q < 0.0) {
        q += 6.2831853071795862;
      }
    }
    b_tmp_data[partialTrueCount] = q;
    partialTrueCount++;
  }
  if (b2) {
    q = lambda[2] + 3.1415926535897931;
    if (std::isnan(q) || std::isinf(q)) {
      q = rtNaN;
    } else {
      b_q = std::abs(q / 6.2831853071795862);
      if (std::abs(b_q - std::floor(b_q + 0.5)) >
          2.2204460492503131E-16 * b_q) {
        q = std::fmod(q, 6.2831853071795862);
      } else {
        q = 0.0;
      }
      if (q == 0.0) {
        q = 0.0;
      } else if (q < 0.0) {
        q += 6.2831853071795862;
      }
    }
    b_tmp_data[partialTrueCount] = q;
    partialTrueCount++;
  }
  if (b3) {
    q = lambda[3] + 3.1415926535897931;
    if (std::isnan(q) || std::isinf(q)) {
      q = rtNaN;
    } else {
      b_q = std::abs(q / 6.2831853071795862);
      if (std::abs(b_q - std::floor(b_q + 0.5)) >
          2.2204460492503131E-16 * b_q) {
        q = std::fmod(q, 6.2831853071795862);
      } else {
        q = 0.0;
      }
      if (q == 0.0) {
        q = 0.0;
      } else if (q < 0.0) {
        q += 6.2831853071795862;
      }
    }
    b_tmp_data[partialTrueCount] = q;
  }
  for (int i{0}; i < trueCount; i++) {
    b_q = lambda[tmp_data[i]] + 3.1415926535897931;
    if (std::isnan(b_q) || std::isinf(b_q)) {
      q = rtNaN;
    } else {
      q = std::abs(b_q / 6.2831853071795862);
      if (std::abs(q - std::floor(q + 0.5)) > 2.2204460492503131E-16 * q) {
        q = std::fmod(b_q, 6.2831853071795862);
      } else {
        q = 0.0;
      }
      if (q == 0.0) {
        q = 0.0;
      } else if (q < 0.0) {
        q += 6.2831853071795862;
      }
    }
    if ((q == 0.0) && (b_q > 0.0)) {
      b_tmp_data[i] = 6.2831853071795862;
    }
  }
  partialTrueCount = 0;
  if (b) {
    lambda[0] = b_tmp_data[0] - 3.1415926535897931;
    partialTrueCount = 1;
  }
  if (b1) {
    lambda[1] = b_tmp_data[partialTrueCount] - 3.1415926535897931;
    partialTrueCount++;
  }
  if (b2) {
    lambda[2] = b_tmp_data[partialTrueCount] - 3.1415926535897931;
    partialTrueCount++;
  }
  if (b3) {
    lambda[3] = b_tmp_data[partialTrueCount] - 3.1415926535897931;
  }
}

} // namespace coder

// End of code generation (wrapToPi.cpp)
