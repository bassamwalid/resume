//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// fk_numerical_terminate.cpp
//
// Code generation for function 'fk_numerical_terminate'
//

// Include files
#include "fk_numerical_terminate.h"
#include "rt_nonfinite.h"

// Function Definitions
void fk_numerical_terminate()
{
}

// End of code generation (fk_numerical_terminate.cpp)
