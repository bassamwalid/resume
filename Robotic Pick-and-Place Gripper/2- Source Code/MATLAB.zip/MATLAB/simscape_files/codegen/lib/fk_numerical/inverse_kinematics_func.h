//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// inverse_kinematics_func.h
//
// Code generation for function 'inverse_kinematics_func'
//

#ifndef INVERSE_KINEMATICS_FUNC_H
#define INVERSE_KINEMATICS_FUNC_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void inverse_kinematics_func(const double q0[4], const double X[3],
                                    double q[4]);

#endif
// End of code generation (inverse_kinematics_func.h)
