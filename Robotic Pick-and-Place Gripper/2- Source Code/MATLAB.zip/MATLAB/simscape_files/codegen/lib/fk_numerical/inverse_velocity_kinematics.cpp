//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// inverse_velocity_kinematics.cpp
//
// Code generation for function 'inverse_velocity_kinematics'
//

// Include files
#include "inverse_velocity_kinematics.h"
#include "jacobian_numerical.h"
#include "pinv.h"
#include "rt_nonfinite.h"
#include <cstring>
#include <emmintrin.h>

// Function Definitions
void inverse_velocity_kinematics(const double q[4], const double V[3],
                                 double q_dot[4])
{
  double J[12];
  double dv[12];
  jacobian_numerical(q, J);
  coder::pinv(J, dv);
  std::memset(&q_dot[0], 0, sizeof(double) << 2);
  for (int i{0}; i < 3; i++) {
    __m128d r;
    __m128d r1;
    __m128d r2;
    int i1;
    i1 = i << 2;
    r = _mm_loadu_pd(&dv[i1]);
    r1 = _mm_loadu_pd(&q_dot[0]);
    r2 = _mm_set1_pd(V[i]);
    _mm_storeu_pd(&q_dot[0], _mm_add_pd(r1, _mm_mul_pd(r, r2)));
    r = _mm_loadu_pd(&dv[i1 + 2]);
    r1 = _mm_loadu_pd(&q_dot[2]);
    _mm_storeu_pd(&q_dot[2], _mm_add_pd(r1, _mm_mul_pd(r, r2)));
  }
}

// End of code generation (inverse_velocity_kinematics.cpp)
