//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_fk_numerical_api.h
//
// Code generation for function 'fk_numerical'
//

#ifndef _CODER_FK_NUMERICAL_API_H
#define _CODER_FK_NUMERICAL_API_H

// Include files
#include "coder_array_mex.h"
#include "emlrt.h"
#include "mex.h"
#include "tmwtypes.h"
#include <algorithm>
#include <cstring>

// Type Definitions
struct rtString_tag_1 {
  coder::array<char_T, 2U> Value;
};
using rtString = rtString_tag_1;

// Variable Declarations
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

// Function Declarations
void fk_numerical(real_T in1[4], real_T X_sym[3]);

void fk_numerical_api(const mxArray *prhs, const mxArray **plhs);

void fk_numerical_atexit();

void fk_numerical_initialize();

void fk_numerical_terminate();

void fk_numerical_xil_shutdown();

void fk_numerical_xil_terminate();

void forward_kinematics_func(real_T q[4], real_T X[3]);

void forward_kinematics_func_api(const mxArray *prhs, const mxArray **plhs);

void forward_velocity_kinematics(real_T q[4], real_T q_dot[4], real_T V[3]);

void forward_velocity_kinematics_api(const mxArray *const prhs[2],
                                     const mxArray **plhs);

void generate_full_trajectory(real_T P_start[3], real_T P_end[3], real_T q[4],
                              rtString *trajectory_type, real_T T_total,
                              real_T dt, coder::array<real_T, 2U> *t_vec,
                              coder::array<real_T, 2U> *q_traj);

void generate_full_trajectory_api(const mxArray *const prhs[6], int32_T nlhs,
                                  const mxArray *plhs[2]);

void generate_trajectory(real_T t, real_T T_total, real_T P_start[3],
                         real_T P_end[3], rtString *trajectory_type,
                         real_T q_previous[4], real_T q_next[4]);

void generate_trajectory_api(const mxArray *const prhs[6],
                             const mxArray **plhs);

void inverse_kinematics_func(real_T q0[4], real_T X[3], real_T q[4]);

void inverse_kinematics_func_api(const mxArray *const prhs[2],
                                 const mxArray **plhs);

void inverse_velocity_kinematics(real_T q[4], real_T V[3], real_T q_dot[4]);

void inverse_velocity_kinematics_api(const mxArray *const prhs[2],
                                     const mxArray **plhs);

void jacobian_numerical(real_T in1[4], real_T J_sym[12]);

void jacobian_numerical_api(const mxArray *prhs, const mxArray **plhs);

#endif
// End of code generation (_coder_fk_numerical_api.h)
