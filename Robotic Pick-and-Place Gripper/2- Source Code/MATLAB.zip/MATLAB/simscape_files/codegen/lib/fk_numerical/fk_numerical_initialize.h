//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// fk_numerical_initialize.h
//
// Code generation for function 'fk_numerical_initialize'
//

#ifndef FK_NUMERICAL_INITIALIZE_H
#define FK_NUMERICAL_INITIALIZE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void fk_numerical_initialize();

#endif
// End of code generation (fk_numerical_initialize.h)
