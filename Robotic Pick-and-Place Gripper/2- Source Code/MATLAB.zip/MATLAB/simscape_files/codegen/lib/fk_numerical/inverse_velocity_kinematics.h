//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// inverse_velocity_kinematics.h
//
// Code generation for function 'inverse_velocity_kinematics'
//

#ifndef INVERSE_VELOCITY_KINEMATICS_H
#define INVERSE_VELOCITY_KINEMATICS_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void inverse_velocity_kinematics(const double q[4], const double V[3],
                                        double q_dot[4]);

#endif
// End of code generation (inverse_velocity_kinematics.h)
