//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// fk_numerical.h
//
// Code generation for function 'fk_numerical'
//

#ifndef FK_NUMERICAL_H
#define FK_NUMERICAL_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void fk_numerical(const double in1[4], double X_sym[3]);

#endif
// End of code generation (fk_numerical.h)
