//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// svd.cpp
//
// Code generation for function 'svd'
//

// Include files
#include "svd.h"
#include "rt_nonfinite.h"
#include "xaxpy.h"
#include "xdotc.h"
#include "xnrm2.h"
#include "xrot.h"
#include "xrotg.h"
#include "xswap.h"
#include "xzlangeM.h"
#include "xzlascl.h"
#include <cmath>
#include <cstring>
#include <emmintrin.h>

// Function Definitions
namespace coder {
namespace internal {
void svd(const double A[12], double U[12], double s[3], double V[9])
{
  __m128d r;
  double b_A[12];
  double Vf[9];
  double work[4];
  double e[3];
  double anrm;
  double b;
  double cscale;
  double nrm;
  double rt;
  double sm;
  double snorm;
  double sqds;
  int b_vectorUB;
  int iter;
  int m;
  int qjj;
  int qp1;
  int qq;
  int qq_tmp;
  int qs;
  int vectorUB;
  boolean_T doscale;
  s[0] = 0.0;
  e[0] = 0.0;
  s[1] = 0.0;
  e[1] = 0.0;
  s[2] = 0.0;
  e[2] = 0.0;
  work[0] = 0.0;
  work[1] = 0.0;
  work[2] = 0.0;
  work[3] = 0.0;
  for (int k{0}; k < 12; k++) {
    b_A[k] = A[k];
    U[k] = 0.0;
  }
  std::memset(&Vf[0], 0, 9U * sizeof(double));
  doscale = false;
  anrm = reflapack::xzlangeM(A);
  cscale = anrm;
  if ((anrm > 0.0) && (anrm < 6.7178761075670888E-139)) {
    doscale = true;
    cscale = 6.7178761075670888E-139;
    reflapack::xzlascl(anrm, b_A);
  }
  for (int q{0}; q < 3; q++) {
    boolean_T apply_transform;
    qp1 = q + 2;
    iter = q << 2;
    qq_tmp = q + iter;
    qq = qq_tmp + 1;
    apply_transform = false;
    nrm = blas::xnrm2(4 - q, b_A, qq_tmp + 1);
    if (nrm > 0.0) {
      apply_transform = true;
      if (b_A[qq_tmp] < 0.0) {
        nrm = -nrm;
      }
      s[q] = nrm;
      if (std::abs(nrm) >= 1.0020841800044864E-292) {
        nrm = 1.0 / nrm;
        qjj = (qq_tmp - q) + 4;
        qs = ((((qjj - qq_tmp) / 2) << 1) + qq_tmp) + 1;
        b_vectorUB = qs - 2;
        for (int k{qq}; k <= b_vectorUB; k += 2) {
          r = _mm_loadu_pd(&b_A[k - 1]);
          _mm_storeu_pd(&b_A[k - 1], _mm_mul_pd(_mm_set1_pd(nrm), r));
        }
        for (int k{qs}; k <= qjj; k++) {
          b_A[k - 1] *= nrm;
        }
      } else {
        qjj = (qq_tmp - q) + 4;
        qs = ((((qjj - qq_tmp) / 2) << 1) + qq_tmp) + 1;
        vectorUB = qs - 2;
        for (int k{qq}; k <= vectorUB; k += 2) {
          r = _mm_loadu_pd(&b_A[k - 1]);
          _mm_storeu_pd(&b_A[k - 1], _mm_div_pd(r, _mm_set1_pd(s[q])));
        }
        for (int k{qs}; k <= qjj; k++) {
          b_A[k - 1] /= s[q];
        }
      }
      b_A[qq_tmp]++;
      s[q] = -s[q];
    } else {
      s[q] = 0.0;
    }
    for (int k{qp1}; k < 4; k++) {
      qjj = q + ((k - 1) << 2);
      if (apply_transform) {
        blas::xaxpy(
            4 - q,
            -(blas::xdotc(4 - q, b_A, qq_tmp + 1, b_A, qjj + 1) / b_A[qq_tmp]),
            qq_tmp + 1, b_A, qjj + 1);
      }
      e[k - 1] = b_A[qjj];
    }
    for (int k{q + 1}; k < 5; k++) {
      qjj = (k + iter) - 1;
      U[qjj] = b_A[qjj];
    }
    if (q <= 0) {
      nrm = blas::xnrm2(e);
      if (nrm == 0.0) {
        e[0] = 0.0;
      } else {
        if (e[1] < 0.0) {
          e[0] = -nrm;
        } else {
          e[0] = nrm;
        }
        nrm = e[0];
        if (std::abs(e[0]) >= 1.0020841800044864E-292) {
          nrm = 1.0 / e[0];
          for (int k{qp1}; k <= 2; k += 2) {
            r = _mm_loadu_pd(&e[1]);
            _mm_storeu_pd(&e[1], _mm_mul_pd(_mm_set1_pd(nrm), r));
          }
        } else {
          for (int k{qp1}; k <= 2; k += 2) {
            r = _mm_loadu_pd(&e[1]);
            _mm_storeu_pd(&e[1], _mm_div_pd(r, _mm_set1_pd(nrm)));
          }
        }
        e[1]++;
        e[0] = -e[0];
        for (int k{qp1}; k < 5; k++) {
          work[k - 1] = 0.0;
        }
        for (int k{qp1}; k < 4; k++) {
          blas::xaxpy(e[k - 1], b_A, ((k - 1) << 2) + 2, work);
        }
        for (int k{qp1}; k < 4; k++) {
          blas::xaxpy(-e[k - 1] / e[1], work, b_A, ((k - 1) << 2) + 2);
        }
      }
      for (int k{qp1}; k < 4; k++) {
        Vf[k - 1] = e[k - 1];
      }
    }
  }
  m = 1;
  e[1] = b_A[9];
  e[2] = 0.0;
  for (int q{2}; q >= 0; q--) {
    qp1 = q + 2;
    vectorUB = q << 2;
    qq = q + vectorUB;
    if (s[q] != 0.0) {
      for (int k{qp1}; k < 4; k++) {
        qjj = (q + ((k - 1) << 2)) + 1;
        blas::xaxpy(4 - q, -(blas::xdotc(4 - q, U, qq + 1, U, qjj) / U[qq]),
                    qq + 1, U, qjj);
      }
      b_vectorUB = ((((4 - q) / 2) << 1) + q) + 1;
      qjj = b_vectorUB - 2;
      for (int k{q + 1}; k <= qjj; k += 2) {
        qs = (k + vectorUB) - 1;
        r = _mm_loadu_pd(&U[qs]);
        _mm_storeu_pd(&U[qs], _mm_mul_pd(r, _mm_set1_pd(-1.0)));
      }
      for (int k{b_vectorUB}; k < 5; k++) {
        qjj = (k + vectorUB) - 1;
        U[qjj] = -U[qjj];
      }
      U[qq]++;
      for (int k{0}; k < q; k++) {
        U[k + vectorUB] = 0.0;
      }
    } else {
      U[vectorUB] = 0.0;
      U[vectorUB + 1] = 0.0;
      U[vectorUB + 2] = 0.0;
      U[vectorUB + 3] = 0.0;
      U[qq] = 1.0;
    }
    if ((q <= 0) && (e[0] != 0.0)) {
      blas::xaxpy(-(blas::xdotc(Vf, Vf, 5) / Vf[1]), Vf, 5);
      blas::xaxpy(-(blas::xdotc(Vf, Vf, 8) / Vf[1]), Vf, 8);
    }
    Vf[3 * q] = 0.0;
    Vf[3 * q + 1] = 0.0;
    Vf[3 * q + 2] = 0.0;
    Vf[q + 3 * q] = 1.0;
  }
  iter = 0;
  snorm = 0.0;
  for (int q{0}; q < 3; q++) {
    nrm = s[q];
    if (nrm != 0.0) {
      rt = std::abs(nrm);
      nrm /= rt;
      s[q] = rt;
      if (q + 1 < 3) {
        e[q] /= nrm;
      }
      qjj = q << 2;
      qs = qjj + 4;
      b_vectorUB = qjj + 5;
      vectorUB = qjj + 3;
      for (int k{qjj + 1}; k <= vectorUB; k += 2) {
        r = _mm_loadu_pd(&U[k - 1]);
        _mm_storeu_pd(&U[k - 1], _mm_mul_pd(_mm_set1_pd(nrm), r));
      }
      for (int k{b_vectorUB}; k <= qs; k++) {
        U[k - 1] *= nrm;
      }
    }
    if (q + 1 < 3) {
      nrm = e[q];
      if (nrm != 0.0) {
        rt = std::abs(nrm);
        nrm = rt / nrm;
        e[q] = rt;
        s[q + 1] *= nrm;
        qjj = 3 * (q + 1);
        qs = qjj + 3;
        b_vectorUB = qjj + 3;
        vectorUB = qjj + 1;
        for (int k{qjj + 1}; k <= vectorUB; k += 2) {
          r = _mm_loadu_pd(&Vf[k - 1]);
          _mm_storeu_pd(&Vf[k - 1], _mm_mul_pd(_mm_set1_pd(nrm), r));
        }
        for (int k{b_vectorUB}; k <= qs; k++) {
          Vf[k - 1] *= nrm;
        }
      }
    }
    snorm = std::fmax(snorm, std::fmax(std::abs(s[q]), std::abs(e[q])));
  }
  while ((m + 2 > 0) && (iter < 75)) {
    boolean_T exitg1;
    qq_tmp = m + 1;
    exitg1 = false;
    while (!(exitg1 || (qq_tmp == 0))) {
      nrm = std::abs(e[qq_tmp - 1]);
      if ((nrm <= 2.2204460492503131E-16 *
                      (std::abs(s[qq_tmp - 1]) + std::abs(s[qq_tmp]))) ||
          (nrm <= 1.0020841800044864E-292) ||
          ((iter > 20) && (nrm <= 2.2204460492503131E-16 * snorm))) {
        e[qq_tmp - 1] = 0.0;
        exitg1 = true;
      } else {
        qq_tmp--;
      }
    }
    if (qq_tmp == m + 1) {
      qjj = 4;
    } else {
      qs = m + 2;
      qjj = m + 2;
      exitg1 = false;
      while ((!exitg1) && (qjj >= qq_tmp)) {
        qs = qjj;
        if (qjj == qq_tmp) {
          exitg1 = true;
        } else {
          nrm = 0.0;
          if (qjj < m + 2) {
            nrm = std::abs(e[qjj - 1]);
          }
          if (qjj > qq_tmp + 1) {
            nrm += std::abs(e[qjj - 2]);
          }
          rt = std::abs(s[qjj - 1]);
          if ((rt <= 2.2204460492503131E-16 * nrm) ||
              (rt <= 1.0020841800044864E-292)) {
            s[qjj - 1] = 0.0;
            exitg1 = true;
          } else {
            qjj--;
          }
        }
      }
      if (qs == qq_tmp) {
        qjj = 3;
      } else if (qs == m + 2) {
        qjj = 1;
      } else {
        qjj = 2;
        qq_tmp = qs;
      }
    }
    switch (qjj) {
    case 1:
      sm = e[m];
      e[m] = 0.0;
      qjj = m + 1;
      for (int k{qjj}; k >= qq_tmp + 1; k--) {
        rt = blas::xrotg(s[k - 1], sm, nrm);
        if (k > qq_tmp + 1) {
          sm = -nrm * e[0];
          e[0] *= rt;
        }
        blas::xrot(Vf, 3 * (k - 1) + 1, 3 * (m + 1) + 1, rt, nrm);
      }
      break;
    case 2:
      sm = e[qq_tmp - 1];
      e[qq_tmp - 1] = 0.0;
      for (int k{qq_tmp + 1}; k <= m + 2; k++) {
        rt = blas::xrotg(s[k - 1], sm, nrm);
        b = e[k - 1];
        sm = -nrm * b;
        e[k - 1] = b * rt;
        blas::b_xrot(U, ((k - 1) << 2) + 1, ((qq_tmp - 1) << 2) + 1, rt, nrm);
      }
      break;
    case 3: {
      double scale;
      qjj = m + 1;
      nrm = s[m + 1];
      scale = std::fmax(
          std::fmax(std::fmax(std::fmax(std::abs(nrm), std::abs(s[m])),
                              std::abs(e[m])),
                    std::abs(s[qq_tmp])),
          std::abs(e[qq_tmp]));
      sm = nrm / scale;
      nrm = s[m] / scale;
      rt = e[m] / scale;
      sqds = s[qq_tmp] / scale;
      b = ((nrm + sm) * (nrm - sm) + rt * rt) / 2.0;
      nrm = sm * rt;
      nrm *= nrm;
      if ((b != 0.0) || (nrm != 0.0)) {
        rt = std::sqrt(b * b + nrm);
        if (b < 0.0) {
          rt = -rt;
        }
        rt = nrm / (b + rt);
      } else {
        rt = 0.0;
      }
      sm = (sqds + sm) * (sqds - sm) + rt;
      nrm = sqds * (e[qq_tmp] / scale);
      for (int k{qq_tmp + 1}; k <= qjj; k++) {
        b = blas::xrotg(sm, nrm, sqds);
        if (k > qq_tmp + 1) {
          e[0] = sm;
        }
        nrm = e[k - 1];
        rt = s[k - 1];
        e[k - 1] = b * nrm - sqds * rt;
        sm = sqds * s[k];
        s[k] *= b;
        blas::xrot(Vf, 3 * (k - 1) + 1, 3 * k + 1, b, sqds);
        s[k - 1] = b * rt + sqds * nrm;
        rt = blas::xrotg(s[k - 1], sm, b);
        nrm = e[k - 1];
        sm = rt * nrm + b * s[k];
        s[k] = -b * nrm + rt * s[k];
        nrm = b * e[k];
        e[k] *= rt;
        blas::b_xrot(U, ((k - 1) << 2) + 1, (k << 2) + 1, rt, b);
      }
      e[m] = sm;
      iter++;
    } break;
    default:
      if (s[qq_tmp] < 0.0) {
        s[qq_tmp] = -s[qq_tmp];
        qjj = 3 * qq_tmp;
        qs = qjj + 3;
        b_vectorUB = qjj + 3;
        vectorUB = qjj + 1;
        for (int k{qjj + 1}; k <= vectorUB; k += 2) {
          r = _mm_loadu_pd(&Vf[k - 1]);
          _mm_storeu_pd(&Vf[k - 1], _mm_mul_pd(r, _mm_set1_pd(-1.0)));
        }
        for (int k{b_vectorUB}; k <= qs; k++) {
          Vf[k - 1] = -Vf[k - 1];
        }
      }
      qp1 = qq_tmp + 1;
      while ((qq_tmp + 1 < 3) && (s[qq_tmp] < s[qp1])) {
        rt = s[qq_tmp];
        s[qq_tmp] = s[qp1];
        s[qp1] = rt;
        blas::xswap(Vf, 3 * qq_tmp + 1, 3 * (qq_tmp + 1) + 1);
        blas::b_xswap(U, (qq_tmp << 2) + 1, ((qq_tmp + 1) << 2) + 1);
        qq_tmp = qp1;
        qp1++;
      }
      iter = 0;
      m--;
      break;
    }
  }
  if (doscale) {
    reflapack::xzlascl(cscale, anrm, s);
  }
  for (int k{0}; k < 3; k++) {
    V[3 * k] = Vf[3 * k];
    qjj = 3 * k + 1;
    V[qjj] = Vf[qjj];
    qjj = 3 * k + 2;
    V[qjj] = Vf[qjj];
  }
}

} // namespace internal
} // namespace coder

// End of code generation (svd.cpp)
