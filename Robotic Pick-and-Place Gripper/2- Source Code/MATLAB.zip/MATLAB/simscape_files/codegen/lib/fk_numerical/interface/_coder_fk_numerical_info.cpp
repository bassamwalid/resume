//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_fk_numerical_info.cpp
//
// Code generation for function 'fk_numerical'
//

// Include files
#include "_coder_fk_numerical_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

// Function Declarations
static const mxArray *emlrtMexFcnResolvedFunctionsInfo();

// Function Definitions
static const mxArray *emlrtMexFcnResolvedFunctionsInfo()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[11]{
      "789ced5c4f73db44145798c2305020c39f96692ffd009d4c1262bbe1161b2769439c4cec"
      "d48d706bc9f23a912d699d95ecda3ee513b4474e0cd39e3a9c98e1c2"
      "910fc0850b5c98e1ca854fc00c431c651d4bcd225b5236caf2de65bdf3d3eeef69edfdf9"
      "eddb95a499fb9b339224bd2fb9b65d73cbf74eebb3a7e51b92d7fcf8",
      "cc69f9a1af4eed4de99aa71dc59f9f961ab61cd473dc8aa59a68d4b28e4ddd522da7d46f"
      "2389201b1b5d543f411aba814aba898ae395c2b066ae8e41a3ca101a"
      "7ece1d20ad55ec981239b0cf3c34c62ba3f15018f77b2d603cfce61f0fff7594af1d928f"
      "f67f3d808fe28d56d5ea9888e89a6a8cf32b11f9df62f2bb481d776a",
      "063ae37b15916f9dc9e7c5bfca3f2e7f5ed9b5f43bc35f805d292213d90e2277962b3bb8"
      "861d5db32b9b2ba52f57b2155b376d4d6da36ae3e4caf1919a3383c6"
      "e98309fdf69767d7bf7d523ec3bf9f40bcf87e7ad7f981271fb5cbe2eb31fa9bf4777783"
      "c137ebc39752f94327f305d95dc1f905bdbc36901bf9a5fc98de06f0",
      "04f92131eabcfa5718ed2f4a1fa37e6facffa7591fde54355cd355cbab9297a793df47e4"
      "2b30f9bc78789d7c7dc4e64c7ef39bb75e1afdaf412fa5f8f5f2d13d"
      "73c1947bdb1b8f74d568ae1ea653693b9303bdf41b2fbdbc19c047f106264f5552afb674"
      "0b99ea5026aa8d8ea55d9a5efe1891afc8e4f3e211e2caf3476c289a",
      "12bf79fed713bebaf973b6fa274f3e6aa2eba63a9fc2f7734bdb64f36136fbd956b99eb5"
      "d32981745394f90cebfbe9f8607d1f0f1facef5d83f5fd74fd2b8cf6"
      "573d5ed5ad2e2236827875629d648c18e778f55695af6efef3c7c77779f251135d37db87"
      "06b6e43dbcd59277b299bd5c2d9f215d81745394f90cf983707c4959",
      "6f280c3f217f30191f35d1f518f207ffdd7f52f4f828e27ddc0ab80f8a8f7673a85b09d9"
      "078bfa3d3e64f279f118f6c15e1b399efb61bc75f9c6af1ae8b214bf"
      "2e97167b1b8bce0e91eb3b3897d1db72bb67e035d0e5a4cd673897108e0fce25c4cb07e7"
      "125c837309d3f5af30da5f549ef728241fedff76001fc5e92ab98b0c",
      "ace94e7f2cbcf6f8a344f487771c5b66f279f1e8f9857346ee5840458d6321bfe05adcfa"
      "39bf276bf9e6c1a0af19f9d4f276215d94774b10c7266e3e431c1b8e"
      "0fe2d878f9208e750de2d8e9fa5718edaf7a1c4b930f10c786cdabffbfe2d86f7e53218e"
      "95e2d7cf9afdd42ad4daa98512de30e47b286b148b9a40fa29ca7c3e",
      "8a781fb04fc6e2f3e2b04f361d1fec93b906fb64d3f5af30da27f51cee47017c14df4716"
      "22aa83aa0e519b487330e9c7eac727017e505cc37544e674eb58baac"
      "6305b21da25bfb527cf981ad003f281e5e4fcf19498ef1ed4dcee77217df79fc374f3e6a"
      "a2eb68e641cb6996d1a074680fd2f2faeec272816cae8aa3a3577d1e",
      "c3f311e1f892727e4f61f809cf474cc6474d741d16fdf90885d13ea9f1eca7017c141fa9"
      "77a3631863129eb47836aa9e9602fca0780cff83be91740595d7fcff"
      "96f3bed7cb17bf7cc7938fda55d5d349e7c37e4bebadcfd7ca85cc7ca3ab0ed6b20ffa4e"
      "5b12474f4599cf10df86e383f8f662f820be750de2dbe9fa073d762d",
      "ae3cb012d10fdee7c12e3b4fa430fc837cef647cd444d761d1f3bda0c3aec17b18fc7c5e"
      "1cdec3301d1f3c27e11abc8761b2feff05ab73eb87",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 25192U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[7]{
      "QualifiedName",    "NumberOfInputs", "NumberOfOutputs", "ConstantInputs",
      "ResolvedFilePath", "TimeStamp",      "Visible"};
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum", "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "AuxData"};
  uint8_T v[216]{
      0U,   1U,   73U,  77U,  0U,   0U,   0U,   0U,   14U,  0U,   0U,   0U,
      200U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,
      2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   4U,   0U,
      17U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,   17U,  0U,   0U,   0U,
      67U,  108U, 97U,  115U, 115U, 69U,  110U, 116U, 114U, 121U, 80U,  111U,
      105U, 110U, 116U, 115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      14U,  0U,   0U,   0U,   112U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      0U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   4U,   0U,   14U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,
      56U,  0U,   0U,   0U,   81U,  117U, 97U,  108U, 105U, 102U, 105U, 101U,
      100U, 78U,  97U,  109U, 101U, 0U,   77U,  101U, 116U, 104U, 111U, 100U,
      115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   80U,  114U, 111U, 112U,
      101U, 114U, 116U, 105U, 101U, 115U, 0U,   0U,   0U,   0U,   72U,  97U,
      110U, 100U, 108U, 101U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 8, 7, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, "QualifiedName",
                emlrtMxCreateString("fk_numerical"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "ResolvedFilePath",
                emlrtMxCreateString(
                    "W:\\Uni Files\\Semester "
                    "9\\Robotics\\MATLAB\\simscape_files\\fk_numerical.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(739968.91157407407));
  emlrtSetField(xEntryPoints, 0, "Visible", emlrtMxCreateLogicalScalar(true));
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 1, "QualifiedName",
                emlrtMxCreateString("jacobian_numerical"));
  emlrtSetField(xEntryPoints, 1, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 1, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 1, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 1, "ResolvedFilePath",
      emlrtMxCreateString(
          "W:\\Uni Files\\Semester "
          "9\\Robotics\\MATLAB\\simscape_files\\jacobian_numerical.m"));
  emlrtSetField(xEntryPoints, 1, "TimeStamp",
                emlrtMxCreateDoubleScalar(739968.91157407407));
  emlrtSetField(xEntryPoints, 1, "Visible", emlrtMxCreateLogicalScalar(true));
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 2, "QualifiedName",
                emlrtMxCreateString("forward_kinematics_func"));
  emlrtSetField(xEntryPoints, 2, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 2, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 2, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 2, "ResolvedFilePath",
      emlrtMxCreateString(
          "W:\\Uni Files\\Semester "
          "9\\Robotics\\MATLAB\\simscape_files\\forward_kinematics_func.m"));
  emlrtSetField(xEntryPoints, 2, "TimeStamp",
                emlrtMxCreateDoubleScalar(739947.7509375));
  emlrtSetField(xEntryPoints, 2, "Visible", emlrtMxCreateLogicalScalar(true));
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 3, "QualifiedName",
                emlrtMxCreateString("inverse_kinematics_func"));
  emlrtSetField(xEntryPoints, 3, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 3, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 3, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 3, "ResolvedFilePath",
      emlrtMxCreateString(
          "W:\\Uni Files\\Semester "
          "9\\Robotics\\MATLAB\\simscape_files\\inverse_kinematics_func.m"));
  emlrtSetField(xEntryPoints, 3, "TimeStamp",
                emlrtMxCreateDoubleScalar(739947.97097222228));
  emlrtSetField(xEntryPoints, 3, "Visible", emlrtMxCreateLogicalScalar(true));
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 4, "QualifiedName",
                emlrtMxCreateString("forward_velocity_kinematics"));
  emlrtSetField(xEntryPoints, 4, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 4, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 4, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 4, "ResolvedFilePath",
                emlrtMxCreateString("W:\\Uni Files\\Semester "
                                    "9\\Robotics\\MATLAB\\simscape_"
                                    "files\\forward_velocity_kinematics.m"));
  emlrtSetField(xEntryPoints, 4, "TimeStamp",
                emlrtMxCreateDoubleScalar(739947.7509375));
  emlrtSetField(xEntryPoints, 4, "Visible", emlrtMxCreateLogicalScalar(true));
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 5, "QualifiedName",
                emlrtMxCreateString("inverse_velocity_kinematics"));
  emlrtSetField(xEntryPoints, 5, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 5, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 5, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 5, "ResolvedFilePath",
                emlrtMxCreateString("W:\\Uni Files\\Semester "
                                    "9\\Robotics\\MATLAB\\simscape_"
                                    "files\\inverse_velocity_kinematics.m"));
  emlrtSetField(xEntryPoints, 5, "TimeStamp",
                emlrtMxCreateDoubleScalar(739947.7509375));
  emlrtSetField(xEntryPoints, 5, "Visible", emlrtMxCreateLogicalScalar(true));
  xInputs = emlrtCreateLogicalMatrix(1, 6);
  emlrtSetField(xEntryPoints, 6, "QualifiedName",
                emlrtMxCreateString("generate_trajectory"));
  emlrtSetField(xEntryPoints, 6, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(6.0));
  emlrtSetField(xEntryPoints, 6, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 6, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 6, "ResolvedFilePath",
      emlrtMxCreateString(
          "W:\\Uni Files\\Semester "
          "9\\Robotics\\MATLAB\\simscape_files\\generate_trajectory.m"));
  emlrtSetField(xEntryPoints, 6, "TimeStamp",
                emlrtMxCreateDoubleScalar(739947.96009259264));
  emlrtSetField(xEntryPoints, 6, "Visible", emlrtMxCreateLogicalScalar(true));
  xInputs = emlrtCreateLogicalMatrix(1, 6);
  emlrtSetField(xEntryPoints, 7, "QualifiedName",
                emlrtMxCreateString("generate_full_trajectory"));
  emlrtSetField(xEntryPoints, 7, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(6.0));
  emlrtSetField(xEntryPoints, 7, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 7, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 7, "ResolvedFilePath",
      emlrtMxCreateString(
          "W:\\Uni Files\\Semester "
          "9\\Robotics\\MATLAB\\simscape_files\\generate_full_trajectory.m"));
  emlrtSetField(xEntryPoints, 7, "TimeStamp",
                emlrtMxCreateDoubleScalar(739968.99591435189));
  emlrtSetField(xEntryPoints, 7, "Visible", emlrtMxCreateLogicalScalar(true));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("25.2.0.3042426 (R2025b) Update 1"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("ly18NsJSIdpGuGlcZO7ZUE"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  emlrtSetField(xResult, 0, "AuxData",
                emlrtMxCreateRowVectorUINT8((const uint8_T *)&v, 216U));
  return xResult;
}

// End of code generation (_coder_fk_numerical_info.cpp)
