//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// main.cpp
//
// Code generation for function 'main'
//

/*************************************************************************/
/* This automatically generated example C++ main file shows how to call  */
/* entry-point functions that MATLAB Coder generated. You must customize */
/* this file for your application. Do not modify this file directly.     */
/* Instead, make a copy of this file, modify it, and integrate it into   */
/* your development environment.                                         */
/*                                                                       */
/* This file initializes entry-point function arguments to a default     */
/* size and value before calling the entry-point functions. It does      */
/* not store or use any values returned from the entry-point functions.  */
/* If necessary, it does pre-allocate memory for returned values.        */
/* You can use this file as a starting point for a main function that    */
/* you can deploy in your application.                                   */
/*                                                                       */
/* After you copy the file, and before you deploy it, you must make the  */
/* following changes:                                                    */
/* * For variable-size function arguments, change the example sizes to   */
/* the sizes that your application requires.                             */
/* * Change the example values of function arguments to the values that  */
/* your application requires.                                            */
/* * If the entry-point functions return values, store these values or   */
/* otherwise use them as required by your application.                   */
/*                                                                       */
/*************************************************************************/

// Include files
#include "main.h"
#include "fk_numerical.h"
#include "fk_numerical_initialize.h"
#include "fk_numerical_terminate.h"
#include "forward_kinematics_func.h"
#include "forward_velocity_kinematics.h"
#include "generate_full_trajectory.h"
#include "generate_trajectory.h"
#include "inverse_kinematics_func.h"
#include "inverse_velocity_kinematics.h"
#include "jacobian_numerical.h"
#include "rt_nonfinite.h"
#include "string1.h"
#include "coder_array.h"

// Function Declarations
static coder::array<char, 2U> argInit_1xUnbounded_char_T();

static void argInit_3x1_real_T(double result[3]);

static void argInit_4x1_real_T(double result[4]);

static char argInit_char_T();

static double argInit_real_T();

static coder::rtString argInit_rtString();

// Function Definitions
static coder::array<char, 2U> argInit_1xUnbounded_char_T()
{
  coder::array<char, 2U> result;
  // Set the size of the array.
  // Change this size to the value that the application requires.
  result.set_size(1, 2);
  // Loop over the array to initialize each element.
  for (int idx1{0}; idx1 < result.size(1); idx1++) {
    // Set the value of the array element.
    // Change this value to the value that the application requires.
    result[idx1] = argInit_char_T();
  }
  return result;
}

static void argInit_3x1_real_T(double result[3])
{
  // Loop over the array to initialize each element.
  for (int idx0{0}; idx0 < 3; idx0++) {
    // Set the value of the array element.
    // Change this value to the value that the application requires.
    result[idx0] = argInit_real_T();
  }
}

static void argInit_4x1_real_T(double result[4])
{
  // Loop over the array to initialize each element.
  for (int idx0{0}; idx0 < 4; idx0++) {
    // Set the value of the array element.
    // Change this value to the value that the application requires.
    result[idx0] = argInit_real_T();
  }
}

static char argInit_char_T()
{
  return '?';
}

static double argInit_real_T()
{
  return 0.0;
}

static coder::rtString argInit_rtString()
{
  coder::rtString result;
  coder::array<char, 2U> r;
  // Set the value of each structure field.
  // Change this value to the value that the application requires.
  r = argInit_1xUnbounded_char_T();
  result.init(r);
  return result;
}

int main(int, char **)
{
  // Initialize the application.
  // You do not need to do this more than one time.
  fk_numerical_initialize();
  // Invoke the entry-point functions.
  // You can call entry-point functions multiple times.
  main_fk_numerical();
  main_jacobian_numerical();
  main_forward_kinematics_func();
  main_inverse_kinematics_func();
  main_forward_velocity_kinematics();
  main_inverse_velocity_kinematics();
  main_generate_trajectory();
  main_generate_full_trajectory();
  // Terminate the application.
  // You do not need to do this more than one time.
  fk_numerical_terminate();
  return 0;
}

void main_fk_numerical()
{
  double dv[4];
  double X_sym[3];
  // Initialize function 'fk_numerical' input arguments.
  // Initialize function input argument 'in1'.
  // Call the entry-point 'fk_numerical'.
  argInit_4x1_real_T(dv);
  fk_numerical(dv, X_sym);
}

void main_forward_kinematics_func()
{
  double dv[4];
  double X[3];
  // Initialize function 'forward_kinematics_func' input arguments.
  // Initialize function input argument 'q'.
  // Call the entry-point 'forward_kinematics_func'.
  argInit_4x1_real_T(dv);
  forward_kinematics_func(dv, X);
}

void main_forward_velocity_kinematics()
{
  double q_tmp[4];
  double V[3];
  // Initialize function 'forward_velocity_kinematics' input arguments.
  // Initialize function input argument 'q'.
  argInit_4x1_real_T(q_tmp);
  // Initialize function input argument 'q_dot'.
  // Call the entry-point 'forward_velocity_kinematics'.
  forward_velocity_kinematics(q_tmp, q_tmp, V);
}

void main_generate_full_trajectory()
{
  coder::rtString trajectory_type;
  coder::array<double, 2U> q_traj;
  coder::array<double, 2U> t_vec;
  double dv[4];
  double P_start_tmp[3];
  double T_total_tmp;
  // Initialize function 'generate_full_trajectory' input arguments.
  // Initialize function input argument 'P_start'.
  argInit_3x1_real_T(P_start_tmp);
  // Initialize function input argument 'P_end'.
  // Initialize function input argument 'q'.
  // Initialize function input argument 'trajectory_type'.
  trajectory_type = argInit_rtString();
  T_total_tmp = argInit_real_T();
  // Call the entry-point 'generate_full_trajectory'.
  argInit_4x1_real_T(dv);
  generate_full_trajectory(P_start_tmp, P_start_tmp, dv, &trajectory_type,
                           T_total_tmp, T_total_tmp, t_vec, q_traj);
}

void main_generate_trajectory()
{
  coder::rtString trajectory_type;
  double dv[4];
  double q_next[4];
  double P_start_tmp[3];
  double t_tmp;
  // Initialize function 'generate_trajectory' input arguments.
  t_tmp = argInit_real_T();
  // Initialize function input argument 'P_start'.
  argInit_3x1_real_T(P_start_tmp);
  // Initialize function input argument 'P_end'.
  // Initialize function input argument 'trajectory_type'.
  trajectory_type = argInit_rtString();
  // Initialize function input argument 'q_previous'.
  // Call the entry-point 'generate_trajectory'.
  argInit_4x1_real_T(dv);
  generate_trajectory(t_tmp, t_tmp, P_start_tmp, P_start_tmp, &trajectory_type,
                      dv, q_next);
}

void main_inverse_kinematics_func()
{
  double dv[4];
  double q[4];
  double dv1[3];
  // Initialize function 'inverse_kinematics_func' input arguments.
  // Initialize function input argument 'q0'.
  // Initialize function input argument 'X'.
  // Call the entry-point 'inverse_kinematics_func'.
  argInit_4x1_real_T(dv);
  argInit_3x1_real_T(dv1);
  inverse_kinematics_func(dv, dv1, q);
}

void main_inverse_velocity_kinematics()
{
  double dv[4];
  double q_dot[4];
  double dv1[3];
  // Initialize function 'inverse_velocity_kinematics' input arguments.
  // Initialize function input argument 'q'.
  // Initialize function input argument 'V'.
  // Call the entry-point 'inverse_velocity_kinematics'.
  argInit_4x1_real_T(dv);
  argInit_3x1_real_T(dv1);
  inverse_velocity_kinematics(dv, dv1, q_dot);
}

void main_jacobian_numerical()
{
  double J_sym[12];
  double dv[4];
  // Initialize function 'jacobian_numerical' input arguments.
  // Initialize function input argument 'in1'.
  // Call the entry-point 'jacobian_numerical'.
  argInit_4x1_real_T(dv);
  jacobian_numerical(dv, J_sym);
}

// End of code generation (main.cpp)
