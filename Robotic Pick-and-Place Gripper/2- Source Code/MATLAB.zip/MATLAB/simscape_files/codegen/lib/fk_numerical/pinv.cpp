//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// pinv.cpp
//
// Code generation for function 'pinv'
//

// Include files
#include "pinv.h"
#include "rt_nonfinite.h"
#include "svd.h"
#include <cmath>
#include <cstring>
#include <emmintrin.h>

// Function Definitions
namespace coder {
void pinv(const double A[12], double X[12])
{
  double C[12];
  double b_A[12];
  double V[9];
  double absx;
  int br;
  int vcol;
  boolean_T p;
  for (int k{0}; k < 3; k++) {
    vcol = k << 2;
    b_A[vcol] = A[k];
    b_A[vcol + 1] = A[k + 3];
    b_A[vcol + 2] = A[k + 6];
    b_A[vcol + 3] = A[k + 9];
  }
  p = true;
  for (int k{0}; k < 12; k++) {
    C[k] = 0.0;
    if (p) {
      absx = b_A[k];
      if (std::isinf(absx) || std::isnan(absx)) {
        p = false;
      }
    } else {
      p = false;
    }
  }
  if (!p) {
    for (int k{0}; k < 12; k++) {
      C[k] = rtNaN;
    }
  } else {
    double U[12];
    double s[3];
    int r;
    boolean_T exitg1;
    internal::svd(b_A, U, s, V);
    absx = std::abs(s[0]);
    if (std::isinf(absx) || std::isnan(absx)) {
      absx = rtNaN;
    } else if (absx < 4.4501477170144028E-308) {
      absx = 4.94065645841247E-324;
    } else {
      std::frexp(absx, &br);
      absx = std::ldexp(1.0, br - 53);
    }
    absx *= 4.0;
    vcol = 0;
    exitg1 = false;
    while ((!exitg1) && (vcol < 3)) {
      if (std::isinf(s[vcol]) || std::isnan(s[vcol])) {
        absx = 1.7976931348623157E+308;
        exitg1 = true;
      } else {
        vcol++;
      }
    }
    r = -1;
    vcol = 0;
    while ((vcol < 3) && (s[vcol] > absx)) {
      r++;
      vcol++;
    }
    if (r + 1 > 0) {
      __m128d b_r;
      int scalarLB;
      vcol = 1;
      for (int k{0}; k <= r; k++) {
        absx = 1.0 / s[k];
        br = vcol + 2;
        scalarLB = vcol + 2;
        for (int b_k{vcol}; b_k <= vcol; b_k += 2) {
          b_r = _mm_loadu_pd(&V[b_k - 1]);
          _mm_storeu_pd(&V[b_k - 1], _mm_mul_pd(_mm_set1_pd(absx), b_r));
        }
        for (int b_k{scalarLB}; b_k <= br; b_k++) {
          V[b_k - 1] *= absx;
        }
        vcol += 3;
      }
      for (int k{0}; k <= 9; k += 3) {
        vcol = k + 1;
        br = k + 3;
        if (vcol <= br) {
          std::memset(&C[vcol + -1], 0,
                      static_cast<unsigned int>((br - vcol) + 1) *
                          sizeof(double));
        }
      }
      br = 0;
      for (int k{0}; k <= 9; k += 3) {
        vcol = -1;
        br++;
        scalarLB = br + (r << 2);
        for (int b_k{br}; b_k <= scalarLB; b_k += 4) {
          int b_scalarLB;
          int i;
          int i1;
          int vectorUB;
          i = k + 1;
          i1 = k + 3;
          b_scalarLB = k + 3;
          vectorUB = k + 1;
          for (int ic{i}; ic <= vectorUB; ic += 2) {
            __m128d r1;
            b_r = _mm_loadu_pd(&V[(vcol + ic) - k]);
            r1 = _mm_loadu_pd(&C[ic - 1]);
            _mm_storeu_pd(
                &C[ic - 1],
                _mm_add_pd(r1, _mm_mul_pd(_mm_set1_pd(U[b_k - 1]), b_r)));
          }
          for (int ic{b_scalarLB}; ic <= i1; ic++) {
            C[ic - 1] += U[b_k - 1] * V[(vcol + ic) - k];
          }
          vcol += 3;
        }
      }
    }
  }
  for (int k{0}; k < 3; k++) {
    vcol = k << 2;
    X[vcol] = C[k];
    X[vcol + 1] = C[k + 3];
    X[vcol + 2] = C[k + 6];
    X[vcol + 3] = C[k + 9];
  }
}

} // namespace coder

// End of code generation (pinv.cpp)
