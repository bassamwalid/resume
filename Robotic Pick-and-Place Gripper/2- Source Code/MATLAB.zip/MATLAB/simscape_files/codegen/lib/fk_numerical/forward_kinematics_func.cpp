//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// forward_kinematics_func.cpp
//
// Code generation for function 'forward_kinematics_func'
//

// Include files
#include "forward_kinematics_func.h"
#include "fk_numerical.h"
#include "rt_nonfinite.h"

// Function Definitions
void forward_kinematics_func(const double q[4], double X[3])
{
  fk_numerical(q, X);
  //  ensure numeric
}

// End of code generation (forward_kinematics_func.cpp)
