//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// dot.cpp
//
// Code generation for function 'dot'
//

// Include files
#include "dot.h"
#include "rt_nonfinite.h"

// Function Definitions
namespace coder {
double dot(const double a[2], const double b[2])
{
  return a[0] * b[0] + a[1] * b[1];
}

} // namespace coder

// End of code generation (dot.cpp)
