//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// dot.h
//
// Code generation for function 'dot'
//

#ifndef DOT_H
#define DOT_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
double dot(const double a[2], const double b[2]);

}

#endif
// End of code generation (dot.h)
