//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// generate_trajectory.cpp
//
// Code generation for function 'generate_trajectory'
//

// Include files
#include "generate_trajectory.h"
#include "atan2.h"
#include "dot.h"
#include "inverse_kinematics_func.h"
#include "mod.h"
#include "norm.h"
#include "rt_nonfinite.h"
#include "strcmp.h"
#include "string1.h"
#include <cmath>
#include <emmintrin.h>

// Function Definitions
void generate_trajectory(double t, double T_total, const double P_start[3],
                         const double P_end[3],
                         const coder::rtString *trajectory_type,
                         const double q_previous[4], double q_next[4])
{
  double X_target[3];
  double dir_xy[2];
  double mid_xy[2];
  double perp[2];
  //  GENERATE_TRAJECTORY
  //  Generates joint angles q for a given time t during a straight line or
  //  circular motion in 3D Cartesian space. Uses constant velocity (no
  //  acceleration profile). Input normalization Force start position as 3x1
  //  column vector [x;y;z] Force end position as 3x1 column vector [x;y;z] Use
  //  previous joint solution as initial guess for IK (very important!)
  //  Trajectory type selection
  if (coder::internal::b_strcmp(trajectory_type)) {
    __m128d r;
    //  ====================== STRAIGHT LINE MOTION =========================
    r = _mm_loadu_pd(&P_start[0]);
    _mm_storeu_pd(
        &X_target[0],
        _mm_add_pd(r,
                   _mm_mul_pd(_mm_div_pd(_mm_sub_pd(_mm_loadu_pd(&P_end[0]), r),
                                         _mm_set1_pd(T_total)),
                              _mm_set1_pd(t))));
    X_target[2] = P_start[2] + (P_end[2] - P_start[2]) / T_total * t;
  } else if (coder::internal::c_strcmp(trajectory_type)) {
    __m128d r;
    __m128d r1;
    double r0;
    double r_t;
    //  ====================== CIRCULAR (HALF CIRCLE) MOTION =================
    //  Center of the circle (midpoint between start and end)
    r = _mm_loadu_pd(&P_start[0]);
    r1 = _mm_loadu_pd(&P_end[0]);
    _mm_storeu_pd(&mid_xy[0], _mm_div_pd(_mm_add_pd(r, r1), _mm_set1_pd(2.0)));
    _mm_storeu_pd(&dir_xy[0], _mm_sub_pd(r1, r));
    perp[0] = -dir_xy[1];
    perp[1] = dir_xy[0];
    r = _mm_loadu_pd(&perp[0]);
    _mm_storeu_pd(&perp[0], _mm_div_pd(r, _mm_set1_pd(coder::c_norm(perp))));
    r = _mm_loadu_pd(&mid_xy[0]);
    _mm_storeu_pd(&dir_xy[0], _mm_sub_pd(_mm_loadu_pd(&P_start[0]), r));
    r0 = coder::dot(dir_xy, perp);
    //  calcualtions for X & Y
    r = _mm_loadu_pd(&perp[0]);
    r1 = _mm_loadu_pd(&mid_xy[0]);
    r = _mm_add_pd(r1, _mm_mul_pd(_mm_set1_pd(r0), r));
    _mm_storeu_pd(&mid_xy[0], r);
    _mm_storeu_pd(&dir_xy[0], _mm_sub_pd(_mm_loadu_pd(&P_start[0]), r));
    r0 = coder::c_norm(dir_xy);
    //  initial radius
    //  final radius
    r = _mm_loadu_pd(&mid_xy[0]);
    _mm_storeu_pd(&dir_xy[0], _mm_sub_pd(_mm_loadu_pd(&P_end[0]), r));
    r_t = r0 + (coder::c_norm(dir_xy) - r0) / T_total * t;
    //  current radius
    if (r_t < 0.005) {
      r_t = 0.005;
    }
    // calculating angle theta
    r0 = coder::b_atan2(P_start[1] - mid_xy[1], P_start[0] - mid_xy[0]);
    //  initial angle
    //  final angle
    r0 +=
        (coder::internal::scalar::b_mod(
             (coder::b_atan2(P_end[1] - mid_xy[1], P_end[0] - mid_xy[0]) - r0) +
             3.1415926535897931) -
         3.1415926535897931) /
        T_total * t;
    //  current angle (this is the key!)
    //  calculations for Z
    //  Z velocity
    // final equation
    X_target[0] = mid_xy[0] + r_t * std::cos(r0);
    X_target[1] = mid_xy[1] + r_t * std::sin(r0);
    X_target[2] = P_start[2] + (P_end[2] - P_start[2]) / T_total * t;
  }
  //  ----- Inverse Kinematics
  //  --------------------------------------------------- Solve IK using the
  //  previous joint angles as initial guess This ensures continuity and fast
  //  convergence → smooth robot motion!
  inverse_kinematics_func(q_previous, X_target, q_next);
}

// End of code generation (generate_trajectory.cpp)
