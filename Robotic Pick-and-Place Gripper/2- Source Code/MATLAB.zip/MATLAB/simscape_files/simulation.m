% Generate first trajectory
[t, q_traj] = generate_full_trajectory(...
    [0; 0; 0.3165], ...    % P_start
    [0.2; 0.15; 0.03], ... % P_end
    [0,0,0,0],...
    'line', 8, 0.02);    % 8 sec, 50 Hz



%pick object
q4_time = 1;
while q4_time > 0
    t(end + 1) = t(end) + 0.02;
    q_traj(end + 1, :) = q_traj(end, :); 
    q_traj(end, end) = q_traj(end, end) + (-pi/2+0.3)*0.02; 

    q4_time = q4_time - 0.02;
end


% Generate second trajectory


[t2, q_traj2] = generate_full_trajectory(...
    [0.2; 0.15; 0.03], ...    % P_start
    [-0.15; -0.15; 0.05], ... % P_end
    q_traj(end, :).',...
    'circle', 8, 0.02);    % 8 sec, 50 Hz


% Concatenate the second trajectory to the first
t2 = t2 + t(end) + 0.02;
t = [t t2];

q_traj2 = [q_traj2(:,1:3), (-pi/2+0.3) * ones(size(q_traj2,1), 1)];
q_traj = [q_traj; q_traj2];





% Create 4 separate timeseries — one per joint
q1_signal = timeseries(q_traj(:,1), t);
q2_signal = timeseries(q_traj(:,2), t);
q3_signal = timeseries(q_traj(:,3), t);
q4_signal = timeseries(q_traj(:,4), t);

% Optional: give them nice names
q1_signal.Name = 'Joint 1 Angle';
q2_signal.Name = 'Joint 2 Angle';
q3_signal.Name = 'Joint 3 Angle';
q4_signal.Name = 'Joint 4 Angle';

% Units and interpolation (recommended)
for sig = {q1_signal, q2_signal, q3_signal, q4_signal}
    sig{1}.DataInfo.Units = 'rad';
    sig{1}.DataInfo.Interpolation = 'linear';
end

% Send to base workspace so Simulink sees them
assignin('base', 'q1_signal', q1_signal);
assignin('base', 'q2_signal', q2_signal);
assignin('base', 'q3_signal', q3_signal);
assignin('base', 'q4_signal', q4_signal);

fprintf('4 separate timeseries created:\n');
fprintf('   q1_signal, q2_signal, q3_signal, q4_signal\n');
fprintf('Now ready for Simulink! Use 4 "From Workspace" blocks.\n');