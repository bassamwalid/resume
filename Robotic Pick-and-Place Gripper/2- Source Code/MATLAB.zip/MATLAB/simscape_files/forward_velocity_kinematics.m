function V = forward_velocity_kinematics(q, q_dot)

    J = jacobian_numerical(q);
    V = J * q_dot();
    V =double(V);

end