import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import serial

class SerialBridgeNode(Node):
    def __init__(self):
        super().__init__('Serial_bridge')

        # Change port if needed: /dev/ttyUSB0 or /dev/ttyACM0
        self.ser = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
        self.get_logger().info("Serial port opened successfully")

        self.subscription = self.create_subscription(
            Float32MultiArray,
            '/cmd_vel_raw',
            self.listener_callback,
            10
        )

    def listener_callback(self, msg):
        speed    = msg.data[0]
        steering = msg.data[1]

        # Format: "S0.50,A15.00\n"
        command = f"S{speed:.2f},A{steering:.2f}\n"
        self.ser.write(command.encode())
        self.get_logger().info(f"Sent: {command.strip()}")

def main(args=None):
    rclpy.init(args=args)
    node = SerialBridgeNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()