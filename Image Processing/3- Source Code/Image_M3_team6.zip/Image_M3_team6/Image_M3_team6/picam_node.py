#!/usr/bin/env python3
"""
picam_node.py  —  Team 6

Captures frames from PiCamera2 using the SAME still-camera configuration style
as the working capture_file test code, then publishes them as sensor_msgs/Image
on /camera/image_raw.
"""

import time

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

try:
    from picamera2 import Picamera2
    PICAMERA2_AVAILABLE = True
except ImportError:
    PICAMERA2_AVAILABLE = False
    import cv2


class CameraNode(Node):
    def __init__(self):
        super().__init__('picam_node')

        # ── Parameters ──────────────────────────────────────────────────────
        self.declare_parameter('width', 640)
        self.declare_parameter('height', 480)
        self.declare_parameter('fps', 60)   # still config is usually safer at lower fps

        width = self.get_parameter('width').value
        height = self.get_parameter('height').value
        fps = self.get_parameter('fps').value

        # ── Publisher ───────────────────────────────────────────────────────
        self.publisher = self.create_publisher(Image, '/camera/image_raw', 10)
        self.bridge = CvBridge()

        # ── Camera init ─────────────────────────────────────────────────────
        if PICAMERA2_AVAILABLE:
            self.cam = Picamera2()

            # Same style as your working image capture code:
            # picam2.create_still_configuration(main={"size": (640, 480)})
            #
            # Added "format": "RGB888" because ROS message is published as rgb8.
            config = self.cam.create_still_configuration(
                main={
                    "size": (width, height),
                    "format": "RGB888"
                }
            )

            self.cam.configure(config)

            self.cam.start()

            # Same warm-up delay as your working capture_file code
            time.sleep(2)

            self.get_logger().info(
                f"PiCamera2 started using STILL configuration {width}x{height}"
            )

        else:
            self.cam = cv2.VideoCapture(0)
            self.cam.set(cv2.CAP_PROP_FRAME_WIDTH, width)
            self.cam.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
            self.get_logger().warn(
                "Picamera2 not found — using OpenCV webcam fallback"
            )

        # ── Timer ───────────────────────────────────────────────────────────
        self.timer = self.create_timer(1.0 / fps, self.timer_callback)

    def timer_callback(self):
        if PICAMERA2_AVAILABLE:
            frame = self.cam.capture_array()  # RGB888 numpy array
        else:
            ret, frame = self.cam.read()
            if not ret:
                self.get_logger().warn("Failed to read frame")
                return

            # OpenCV gives BGR, convert to RGB
            frame = frame[:, :, ::-1]

        msg = self.bridge.cv2_to_imgmsg(frame, encoding='rgb8')
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'camera_link'

        self.publisher.publish(msg)

    def destroy_node(self):
        if PICAMERA2_AVAILABLE:
            self.cam.stop()
        else:
            self.cam.release()

        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = CameraNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()