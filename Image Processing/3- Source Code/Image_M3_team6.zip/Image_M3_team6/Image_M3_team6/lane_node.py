#!/usr/bin/env python3
"""
lane_node.py — Team 6

This ROS 2 node subscribes to /camera/image_raw, detects the two black lane
boundaries printed on a white background, finds the lane centre, converts the
lookahead point from image pixels to real ground coordinates using homography,
and publishes speed + steering angle to /cmd_vel_raw.

Main pipeline:
  1. Read camera frame.
  2. Crop ROI for lane detection.
  3. Convert ROI to grayscale and blur it.
  4. Threshold dark pixels so black lane lines become white pixels in binary.
  5. Use morphology to remove small noise.
  6. Extract lane pixels row-by-row and fit left/right splines.
  7. Use continuity checks so lanes do not jump from left to right.
  8. Stop tracking a lane if it disappears for many rows, so it cannot reconnect
     to a wrong lane segment later.
  9. Reject invalid lane pairs when left crosses right or width is unrealistic.
 10. If both lanes exist, compute the centerline in ground-metre space using homography.
 11. If only one lane exists, reconstruct the centerline by shifting that detected
     lane by half the real lane width in metres, not by pixel width.
 12. If no lanes exist, use pose-transformed memory spline. Since this node has
     no odometry/pose input yet, the pose transform is currently identity.
 13. Run a Kalman-style target update: predict every frame, correct when a
     detected/reconstructed centerline is available.
 14. Convert the final lookahead target from full-image pixels to ground metres
     using homography.
 15. Apply pure pursuit using metric x/y ground coordinates.
 16. If only one lane is detected, force the steering direction toward the
     missing lane side as an emergency correction.
 17. Publish [speed, steering_angle].
 18. Save and publish debug images showing exactly what the program detected.

Important calibration note:
  HOMOGRAPHY_IMAGE_POINTS are full raw-image pixel coordinates, NOT cropped ROI
  coordinates. Whenever a point is calculated inside the ROI, roi_start is added
  back to its y-coordinate before using the homography.
"""

import os
import math
import csv
import time

import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Float32MultiArray
from cv_bridge import CvBridge


# ═══════════════════════════════════════════════════════════════════════════
# Homography calibration points
# ═══════════════════════════════════════════════════════════════════════════

HOMOGRAPHY_IMAGE_POINTS = np.array(
    [
        [44, 229],     # P1 near left
        [530, 244],    # P2 near right
        [168, 128],    # P3 far left
        [411, 136],    # P4 far right
    ],
    dtype=np.float32,
)

HOMOGRAPHY_GROUND_POINTS_M = np.array(
    [
        [0.40, -0.15],  # P1 near left
        [0.40, 0.15],   # P2 near right
        [0.80, -0.15],  # P3 far left
        [0.80, 0.15],   # P4 far right
    ],
    dtype=np.float32,
)


def image_point_to_ground_m(homography: np.ndarray, x_px: float, y_px: float):
    """Take a pixel point and convert it to real-life ground coordinates."""
    point = np.array([[[x_px, y_px]]], dtype=np.float32)
    ground = cv2.perspectiveTransform(point, homography)[0, 0]

    forward_m = float(ground[0])
    lateral_m = float(ground[1])

    return forward_m, lateral_m


# ═══════════════════════════════════════════════════════════════════════════
# Pure pursuit
# ═══════════════════════════════════════════════════════════════════════════

def pure_pursuit_angle_metric(forward_m: float,
                              lateral_m: float,
                              wheelbase_m: float) -> float:
    if forward_m <= 0.01:
        return 90.0

    lookahead_dist_sq = forward_m**2 + lateral_m**2
    if lookahead_dist_sq <= 1e-6:
        return 90.0

    curvature = 2.0 * lateral_m / lookahead_dist_sq
    delta_rad = math.atan(curvature * wheelbase_m)
    delta_deg = math.degrees(delta_rad)

    # Existing convention from your code:
    # 90 = straight, bigger than 90 = right, smaller than 90 = left.
    servo_angle = 90.0 + delta_deg
    return float(np.clip(servo_angle, 45.0, 135.0))


# ═══════════════════════════════════════════════════════════════════════════
# Helper functions/classes
# ═══════════════════════════════════════════════════════════════════════════

def clamp_int(value: float, low: int, high: int) -> int:
    """Clamp a number and return it as an integer."""
    return int(max(low, min(high, value)))


class SplineCurve:
    """
    Simple cubic Hermite spline for x = f(y).

    This avoids adding scipy as a dependency on the Raspberry Pi.
    The lane is stored as y-points and x-points, then evaluated at any requested y row.
    """

    def __init__(self, y_values, x_values):
        y = np.asarray(y_values, dtype=np.float32)
        x = np.asarray(x_values, dtype=np.float32)

        valid = np.isfinite(y) & np.isfinite(x)
        y = y[valid]
        x = x[valid]

        if len(y) < 2:
            raise ValueError('SplineCurve needs at least 2 valid points')

        order = np.argsort(y)
        y = y[order]
        x = x[order]

        # Merge duplicate y rows by averaging their x-values.
        unique_y, inverse = np.unique(y, return_inverse=True)
        unique_x = np.zeros_like(unique_y, dtype=np.float32)
        counts = np.zeros_like(unique_y, dtype=np.float32)

        for i, group_index in enumerate(inverse):
            unique_x[group_index] += x[i]
            counts[group_index] += 1.0

        unique_x = unique_x / np.maximum(counts, 1.0)

        if len(unique_y) < 2:
            raise ValueError('SplineCurve needs at least 2 unique y rows')

        self.y = unique_y.astype(np.float32)
        self.x = unique_x.astype(np.float32)
        self.m = self._compute_tangents(self.y, self.x)

    @staticmethod
    def _compute_tangents(y: np.ndarray, x: np.ndarray) -> np.ndarray:
        """Estimate dx/dy at every spline control point."""
        n = len(y)
        m = np.zeros(n, dtype=np.float32)

        if n == 2:
            slope = (x[1] - x[0]) / max(float(y[1] - y[0]), 1e-6)
            m[:] = slope
            return m

        m[0] = (x[1] - x[0]) / max(float(y[1] - y[0]), 1e-6)
        m[-1] = (x[-1] - x[-2]) / max(float(y[-1] - y[-2]), 1e-6)

        for i in range(1, n - 1):
            m[i] = (x[i + 1] - x[i - 1]) / max(float(y[i + 1] - y[i - 1]), 1e-6)

        return m

    def evaluate(self, y_query, extrapolate=False, x_min=None, x_max=None):
        """
        Evaluate x at one y value or many y values.

        If extrapolate=False:
            y values outside the detected spline range are clipped to the closest endpoint.

        If extrapolate=True:
            y values outside the detected spline range are continued using the endpoint tangent.
            This lets a lane continue through a gap instead of becoming flat.
        """
        scalar_input = np.isscalar(y_query)
        q_original = np.atleast_1d(np.asarray(y_query, dtype=np.float32))

        q = np.clip(q_original, self.y[0], self.y[-1])

        indices = np.searchsorted(self.y, q, side='right') - 1
        indices = np.clip(indices, 0, len(self.y) - 2)

        y0 = self.y[indices]
        y1 = self.y[indices + 1]
        x0 = self.x[indices]
        x1 = self.x[indices + 1]
        m0 = self.m[indices]
        m1 = self.m[indices + 1]

        dy = np.maximum(y1 - y0, 1e-6)
        t = (q - y0) / dy

        h00 = 2.0 * t**3 - 3.0 * t**2 + 1.0
        h10 = t**3 - 2.0 * t**2 + t
        h01 = -2.0 * t**3 + 3.0 * t**2
        h11 = t**3 - t**2

        out = h00 * x0 + h10 * dy * m0 + h01 * x1 + h11 * dy * m1

        if extrapolate:
            above_first_point = q_original < self.y[0]
            out[above_first_point] = (
                self.x[0]
                + self.m[0] * (q_original[above_first_point] - self.y[0])
            )

            below_last_point = q_original > self.y[-1]
            out[below_last_point] = (
                self.x[-1]
                + self.m[-1] * (q_original[below_last_point] - self.y[-1])
            )

            if x_min is not None or x_max is not None:
                low = -1e9 if x_min is None else float(x_min)
                high = 1e9 if x_max is None else float(x_max)
                out = np.clip(out, low, high)

        if scalar_input:
            return float(out[0])

        return out.astype(np.float32)

    def copy(self):
        """Return a copy of the spline."""
        return SplineCurve(self.y.copy(), self.x.copy())


# ═══════════════════════════════════════════════════════════════════════════
# Main ROS 2 node
# ═══════════════════════════════════════════════════════════════════════════

class LaneDetectionNode(Node):
    def __init__(self):
        super().__init__('lane_node')

        # ───────────────────────────────────────────────────────────────────
        # Tunable parameters
        # ───────────────────────────────────────────────────────────────────

        self.declare_parameter('roi_top_fraction', 0.25)
        self.declare_parameter('roi_bottom_fraction', 0.10)

        self.declare_parameter('blur_kernel', 5)
        self.declare_parameter('dark_threshold', 125)
        self.declare_parameter('morph_kernel_size', 3)

        self.declare_parameter('continuity_margin_px', 60)
        self.declare_parameter('min_fit_points', 10)

        self.declare_parameter('lookahead_fraction', 0.85)
        self.declare_parameter('wheelbase_m', 0.255)
        self.declare_parameter('drive_speed', 0.7)
        self.declare_parameter('smoothing_alpha', 0.9)

        # Real lane width used when only one boundary is visible.
        # Your homography points use left=-0.15 m and right=+0.15 m,
        # so the default lane width is 0.30 m.
        self.declare_parameter('lane_width_m', 0.30)

        # Emergency steering correction when only one lane is visible.
        # 15 deg means:
        #   left lane only  -> at least 105 deg
        #   right lane only -> at most 75 deg
        # If you want the old hard behavior, set this to 45.
        self.declare_parameter('one_lane_forced_turn_deg', 35.0)

        self.declare_parameter('debug_save_interval', 30)
        self.declare_parameter('debug_dir', os.path.expanduser('~/lane_debug'))
        self.declare_parameter('publish_debug_image', True)

        # KPI logging parameters.
        # These only measure and save values; they do not change the control logic.
        self.declare_parameter('kpi_logging_enabled', True)
        self.declare_parameter('kpi_file', os.path.expanduser('~/lane_debug/kpi_metrics.csv'))
        self.declare_parameter('kpi_summary_file', os.path.expanduser('~/lane_debug/kpi_summary.txt'))
        self.declare_parameter('kpi_summary_interval', 30)

        self.image_to_ground_H = cv2.getPerspectiveTransform(
            HOMOGRAPHY_IMAGE_POINTS,
            HOMOGRAPHY_GROUND_POINTS_M,
        )

        self.ground_to_image_H = cv2.getPerspectiveTransform(
            HOMOGRAPHY_GROUND_POINTS_M,
            HOMOGRAPHY_IMAGE_POINTS,
        )

        self._frame_count = 0

        # Spline memory.
        self.prev_left_spline = None
        self.prev_right_spline = None
        self.prev_center_spline = None
        self.prev_lane_width_px = None

        # Steering memory.
        self.smoothed_angle = 90.0

        # Kalman-style lookahead target memory.
        # State = [lookahead_x_px, lookahead_x_velocity_px_per_frame]
        self.kalman_initialized = False
        self.kalman_state = np.array([0.0, 0.0], dtype=np.float32)
        self.kalman_P = np.eye(2, dtype=np.float32) * 100.0

        # ROS interfaces.
        self.bridge = CvBridge()

        self.sub = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10,
        )

        self.pub = self.create_publisher(
            Float32MultiArray,
            '/cmd_vel_raw',
            10,
        )

        self.debug_pub = self.create_publisher(
            Image,
            '/lane_debug_image',
            10,
        )

        debug_interval = self.get_parameter('debug_save_interval').value
        debug_dir = self.get_parameter('debug_dir').value
        if debug_interval > 0:
            os.makedirs(debug_dir, exist_ok=True)
            self.get_logger().info(f'Debug images will be saved to: {debug_dir}')

        self._init_kpi_logging()

        self.get_logger().info(
            'Lane detection node ready with spline fitting, metric one-lane reconstruction, and one-lane steering fallback'
        )

    # ─────────────────────────────────────────────────────────────────────
    # Main callback
    # ─────────────────────────────────────────────────────────────────────
    def image_callback(self, msg: Image):
        """Run the complete lane-detection and steering pipeline on one frame."""
        frame_start_time = time.perf_counter()
        frame_wall_time = time.time()

        self._frame_count += 1

        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        frame_h, frame_w = frame.shape[:2]

        if self._frame_count == 1:
            self.get_logger().info(
                f'First frame: shape={frame.shape}, min={frame.min()}, max={frame.max()}'
            )

        save_dir = self._prepare_debug_folder_if_needed()
        do_save = save_dir is not None

        # ───────────────────────────────────────────────────────────────────
        # 1. ROI crop
        # ───────────────────────────────────────────────────────────────────
        roi_top_fraction = float(self.get_parameter('roi_top_fraction').value)
        roi_bottom_fraction = float(self.get_parameter('roi_bottom_fraction').value)

        roi_top_fraction = float(np.clip(roi_top_fraction, 0.0, 0.90))
        roi_bottom_fraction = float(np.clip(roi_bottom_fraction, 0.0, 0.90))

        roi_start = int(frame_h * roi_top_fraction)
        roi_end = int(frame_h * (1.0 - roi_bottom_fraction))

        min_roi_height = 40
        if roi_end <= roi_start + min_roi_height:
            self.get_logger().warn(
                f'Invalid ROI top/bottom fractions: top={roi_top_fraction:.2f}, '
                f'bottom={roi_bottom_fraction:.2f}. Falling back to full height.'
            )
            roi_start = 0
            roi_end = frame_h

        roi = frame[roi_start:roi_end, :]

        if do_save:
            cv2.imwrite(os.path.join(save_dir, 'raw_roi.jpg'), roi)

        # ───────────────────────────────────────────────────────────────────
        # 2. Convert ROI to grayscale and blur it
        # ───────────────────────────────────────────────────────────────────
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

        blur_kernel = int(self.get_parameter('blur_kernel').value)
        if blur_kernel % 2 == 0:
            blur_kernel += 1

        blurred = cv2.GaussianBlur(gray, (blur_kernel, blur_kernel), 0)

        # ───────────────────────────────────────────────────────────────────
        # 3. Dark threshold
        # ───────────────────────────────────────────────────────────────────
        dark_threshold = int(self.get_parameter('dark_threshold').value)
        _, binary = cv2.threshold(
            blurred,
            dark_threshold,
            255,
            cv2.THRESH_BINARY_INV,
        )

        if do_save:
            cv2.imwrite(os.path.join(save_dir, 'threshold.jpg'), binary)

        # ───────────────────────────────────────────────────────────────────
        # 4. Morphology
        # ───────────────────────────────────────────────────────────────────
        morph_kernel_size = int(self.get_parameter('morph_kernel_size').value)
        morph_kernel_size = max(1, morph_kernel_size)
        kernel = np.ones((morph_kernel_size, morph_kernel_size), np.uint8)

        binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel)

        if do_save:
            cv2.imwrite(os.path.join(save_dir, 'morphed.jpg'), binary)

        # ───────────────────────────────────────────────────────────────────
        # 5. Detect lane pixels and fit lane splines
        # ───────────────────────────────────────────────────────────────────
        left_spline, right_spline, left_conf, right_conf, spline_debug = self._spline_lane_fit(binary)

        if do_save:
            cv2.imwrite(os.path.join(save_dir, 'spline_fit.jpg'), spline_debug)

        roi_h = binary.shape[0]
        lookahead_fraction = float(self.get_parameter('lookahead_fraction').value)
        lookahead_fraction = float(np.clip(lookahead_fraction, 0.05, 0.95))

        lookahead_y_roi = int(roi_h * (1.0 - lookahead_fraction))
        lookahead_y_roi = clamp_int(lookahead_y_roi, 0, roi_h - 1)

        # ───────────────────────────────────────────────────────────────────
        # 6. Both lanes / one lane / memory logic
        # ───────────────────────────────────────────────────────────────────
        left_good = left_spline is not None
        right_good = right_spline is not None

        detection_status = 'NO LANE - NO MEMORY'
        target_mode = 'none'

        center_spline = None
        used_left_spline = left_spline
        used_right_spline = right_spline
        detection_based_target = False

        # Case 1: both lanes detected.
        if left_good and right_good:
            center_spline = self._compute_metric_center_spline_from_pair(
                left_spline=left_spline,
                right_spline=right_spline,
                roi_h=roi_h,
                roi_start=roi_start,
            )

            lane_width_px = self._estimate_lane_width_px(left_spline, right_spline)

            if center_spline is not None and lane_width_px is not None:
                self.prev_left_spline = left_spline.copy()
                self.prev_right_spline = right_spline.copy()
                self.prev_center_spline = center_spline.copy()
                self.prev_lane_width_px = float(lane_width_px)

                detection_status = 'BOTH LANES - METRIC CENTERLINE'
                target_mode = 'both_lanes'
                detection_based_target = True

        # Case 2: only one lane detected.
        elif left_good or right_good:
            if left_good:
                # Left boundary is visible.
                # Center is half lane width to the right of the left boundary in ground metres.
                center_spline = self._compute_metric_offset_center_spline_from_one_lane(
                    boundary_spline=left_spline,
                    side='left',
                    roi_h=roi_h,
                    roi_start=roi_start,
                )

                used_left_spline = left_spline
                used_right_spline = None

                if center_spline is not None:
                    self.prev_left_spline = left_spline.copy()
                    self.prev_center_spline = center_spline.copy()

                    detection_status = 'LEFT ONLY - METRIC CENTER OFFSET'
                    target_mode = 'left_only'
                    detection_based_target = True
                else:
                    detection_status = 'LEFT ONLY - OFFSET FAILED'

            else:
                # Right boundary is visible.
                # Center is half lane width to the left of the right boundary in ground metres.
                center_spline = self._compute_metric_offset_center_spline_from_one_lane(
                    boundary_spline=right_spline,
                    side='right',
                    roi_h=roi_h,
                    roi_start=roi_start,
                )

                used_left_spline = None
                used_right_spline = right_spline

                if center_spline is not None:
                    self.prev_right_spline = right_spline.copy()
                    self.prev_center_spline = center_spline.copy()

                    detection_status = 'RIGHT ONLY - METRIC CENTER OFFSET'
                    target_mode = 'right_only'
                    detection_based_target = True
                else:
                    detection_status = 'RIGHT ONLY - OFFSET FAILED'

        # Case 3: no lane detected.
        else:
            center_spline = self._pose_transform_memory_spline()
            if center_spline is not None:
                detection_status = 'NO LANE - MEMORY SPLINE'
                target_mode = 'memory'
                detection_based_target = True

        # If detection/reconstruction failed, try memory.
        if not detection_based_target:
            memory_spline = self._pose_transform_memory_spline()
            if memory_spline is not None:
                center_spline = memory_spline
                detection_status = detection_status + ' -> USING MEMORY'
                target_mode = 'memory'
                detection_based_target = True

        # ───────────────────────────────────────────────────────────────────
        # 7. Kalman update and pure pursuit target selection
        # ───────────────────────────────────────────────────────────────────
        steering_angle = 90.0
        speed = 0.0
        lookahead_data = None

        predicted_x = self._kalman_predict(frame_w)
        final_mid_x = None
        measured_mid_x = None

        if detection_based_target and center_spline is not None:
            measured_mid_x = float(
                center_spline.evaluate(
                    lookahead_y_roi,
                    extrapolate=True,
                    x_min=-1000,
                    x_max=2000,
                )
            )
            measured_mid_x = float(np.clip(measured_mid_x, 0, frame_w - 1))

            if target_mode == 'both_lanes':
                measurement_noise = 4.0
            elif target_mode in ['left_only', 'right_only']:
                measurement_noise = 18.0
            else:
                measurement_noise = 36.0

            final_mid_x = self._kalman_correct(measured_mid_x, frame_w, measurement_noise)

        elif predicted_x is not None:
            final_mid_x = predicted_x
            detection_status = detection_status + ' -> KALMAN PREDICT ONLY'
            target_mode = 'kalman_only'

        has_pure_pursuit_target = final_mid_x is not None

        if has_pure_pursuit_target:
            final_mid_x = float(np.clip(final_mid_x, 0, frame_w - 1))

            lookahead_y_full = float(roi_start + lookahead_y_roi)

            target_forward_m, target_lateral_m = image_point_to_ground_m(
                self.image_to_ground_H,
                final_mid_x,
                lookahead_y_full,
            )

            steering_angle = pure_pursuit_angle_metric(
                target_forward_m,
                target_lateral_m,
                float(self.get_parameter('wheelbase_m').value),
            )

            # Emergency one-lane direction correction.
            # 90 = straight, >90 = right, <90 = left.
            forced_turn_deg = float(self.get_parameter('one_lane_forced_turn_deg').value)
            forced_turn_deg = float(np.clip(forced_turn_deg, 0.0, 45.0))

            if target_mode == 'left_only':
                # Only the left boundary is visible, so the missing side/center is to the right.
                steering_angle = max(steering_angle, 90.0 + forced_turn_deg)

            elif target_mode == 'right_only':
                # Only the right boundary is visible, so the missing side/center is to the left.
                steering_angle = min(steering_angle, 90.0 - forced_turn_deg)

            steering_angle = float(np.clip(steering_angle, 45.0, 135.0))

            speed = float(self.get_parameter('drive_speed').value)

            lookahead_data = {
                'lookahead_y_roi': lookahead_y_roi,
                'lookahead_y_full': lookahead_y_full,
                'mid_x': final_mid_x,
                'measured_mid_x': measured_mid_x,
                'predicted_mid_x': predicted_x,
                'target_forward_m': target_forward_m,
                'target_lateral_m': target_lateral_m,
                'steering_angle': steering_angle,
                'left_conf': left_conf,
                'right_conf': right_conf,
                'detection_status': detection_status,
                'target_mode': target_mode,
            }

        # ───────────────────────────────────────────────────────────────────
        # 8. Smooth steering angle
        # ───────────────────────────────────────────────────────────────────
        alpha = float(self.get_parameter('smoothing_alpha').value)
        alpha = float(np.clip(alpha, 0.0, 1.0))
        self.smoothed_angle = alpha * steering_angle + (1.0 - alpha) * self.smoothed_angle

        # ───────────────────────────────────────────────────────────────────
        # 9. Draw/save/publish debug overlay
        # ───────────────────────────────────────────────────────────────────
        overlay = self._draw_lane_overlay(
            frame=frame,
            roi_start=roi_start,
            roi_end=roi_end,
            roi_shape=binary.shape,
            left_spline=used_left_spline,
            right_spline=used_right_spline,
            center_spline=center_spline,
            valid_target=has_pure_pursuit_target,
            detection_status=detection_status,
            lookahead_data=lookahead_data,
        )

        if do_save:
            cv2.imwrite(os.path.join(save_dir, 'lane_overlay.jpg'), overlay)
            self.get_logger().info(f'Saved debug frame {self._frame_count:06d} to {save_dir}')

        if bool(self.get_parameter('publish_debug_image').value):
            debug_msg = self.bridge.cv2_to_imgmsg(overlay, encoding='bgr8')
            debug_msg.header = msg.header
            self.debug_pub.publish(debug_msg)

        # ───────────────────────────────────────────────────────────────────
        # 10. Publish speed and steering angle
        # ───────────────────────────────────────────────────────────────────
        out_msg = Float32MultiArray()
        out_msg.data = [float(speed), float(self.smoothed_angle)]
        self.pub.publish(out_msg)

        self._update_kpi_metrics(
            frame_start_time=frame_start_time,
            frame_wall_time=frame_wall_time,
            frame_w=frame_w,
            frame_h=frame_h,
            roi_start=roi_start,
            roi_end=roi_end,
            left_good=left_good,
            right_good=right_good,
            left_conf=left_conf,
            right_conf=right_conf,
            detection_status=detection_status,
            target_mode=target_mode,
            has_pure_pursuit_target=has_pure_pursuit_target,
            speed=speed,
            raw_steering_angle=steering_angle,
            smoothed_steering_angle=self.smoothed_angle,
            lookahead_data=lookahead_data,
        )

        self.get_logger().debug(
            f'status={detection_status}, mode={target_mode}, speed={speed:.2f}, angle={self.smoothed_angle:.1f}'
        )

    # ─────────────────────────────────────────────────────────────────────
    # KPI logging helpers
    # ─────────────────────────────────────────────────────────────────────
    def _init_kpi_logging(self):
        """Prepare KPI CSV and summary files without affecting control logic."""
        self.kpi_logging_enabled = bool(self.get_parameter('kpi_logging_enabled').value)

        self.kpi_file = self.get_parameter('kpi_file').value
        self.kpi_summary_file = self.get_parameter('kpi_summary_file').value
        self.kpi_summary_interval = int(self.get_parameter('kpi_summary_interval').value)
        self.kpi_summary_interval = max(1, self.kpi_summary_interval)

        self.kpi_start_wall_time = time.time()
        self.kpi_start_perf_time = time.perf_counter()
        self.kpi_prev_frame_start_time = None
        self.kpi_prev_smoothed_angle = None

        self.kpi_total_frames = 0
        self.kpi_valid_target_frames = 0
        self.kpi_no_target_frames = 0

        self.kpi_both_lane_frames = 0
        self.kpi_left_only_frames = 0
        self.kpi_right_only_frames = 0
        self.kpi_memory_frames = 0
        self.kpi_kalman_only_frames = 0
        self.kpi_no_lane_frames = 0

        self.kpi_left_detected_frames = 0
        self.kpi_right_detected_frames = 0

        self.kpi_processing_time_sum_ms = 0.0
        self.kpi_processing_time_max_ms = 0.0

        self.kpi_left_conf_sum = 0.0
        self.kpi_right_conf_sum = 0.0

        self.kpi_speed_sum = 0.0
        self.kpi_steering_sum = 0.0
        self.kpi_abs_steering_from_center_sum = 0.0
        self.kpi_max_abs_steering_from_center = 0.0

        self.kpi_steering_delta_sum = 0.0
        self.kpi_max_steering_delta = 0.0

        self.kpi_fields = [
            'frame',
            'unix_time_s',
            'elapsed_time_s',
            'processing_time_ms',
            'instant_fps',
            'average_fps',
            'frame_width_px',
            'frame_height_px',
            'roi_start_px',
            'roi_end_px',
            'left_detected',
            'right_detected',
            'both_lanes_detected',
            'one_lane_detected',
            'no_lane_detected',
            'left_confidence',
            'right_confidence',
            'has_pure_pursuit_target',
            'target_mode',
            'detection_status',
            'lookahead_mid_x_px',
            'measured_mid_x_px',
            'predicted_mid_x_px',
            'target_forward_m',
            'target_lateral_m',
            'raw_steering_angle_deg',
            'smoothed_steering_angle_deg',
            'steering_change_deg',
            'abs_steering_from_center_deg',
            'speed_command',
            'prev_lane_width_px',
        ]

        if not self.kpi_logging_enabled:
            self.get_logger().info('KPI logging is disabled')
            return

        try:
            os.makedirs(os.path.dirname(self.kpi_file), exist_ok=True)
            os.makedirs(os.path.dirname(self.kpi_summary_file), exist_ok=True)

            with open(self.kpi_file, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=self.kpi_fields)
                writer.writeheader()

            self._write_kpi_summary()
            self.get_logger().info(f'KPI metrics will be saved to: {self.kpi_file}')
            self.get_logger().info(f'KPI summary will be saved to: {self.kpi_summary_file}')

        except OSError as exc:
            self.kpi_logging_enabled = False
            self.get_logger().warn(f'Could not create KPI files. KPI logging disabled. Error: {exc}')

    @staticmethod
    def _kpi_format(value, digits=3):
        """Return rounded numeric values for CSV, while keeping missing values empty."""
        if value is None:
            return ''

        try:
            value = float(value)
        except (TypeError, ValueError):
            return value

        if not np.isfinite(value):
            return ''

        return round(value, digits)

    def _update_kpi_metrics(self,
                            frame_start_time: float,
                            frame_wall_time: float,
                            frame_w: int,
                            frame_h: int,
                            roi_start: int,
                            roi_end: int,
                            left_good: bool,
                            right_good: bool,
                            left_conf: float,
                            right_conf: float,
                            detection_status: str,
                            target_mode: str,
                            has_pure_pursuit_target: bool,
                            speed: float,
                            raw_steering_angle: float,
                            smoothed_steering_angle: float,
                            lookahead_data):
        """Save useful KPI values for each frame. This does not modify the control output."""
        if not self.kpi_logging_enabled:
            return

        now_perf = time.perf_counter()
        processing_time_ms = (now_perf - frame_start_time) * 1000.0
        elapsed_time_s = now_perf - self.kpi_start_perf_time

        if self.kpi_prev_frame_start_time is None:
            instant_fps = None
        else:
            frame_period_s = frame_start_time - self.kpi_prev_frame_start_time
            instant_fps = 1.0 / frame_period_s if frame_period_s > 1e-9 else None

        self.kpi_prev_frame_start_time = frame_start_time

        self.kpi_total_frames += 1

        if has_pure_pursuit_target:
            self.kpi_valid_target_frames += 1
        else:
            self.kpi_no_target_frames += 1

        if target_mode == 'both_lanes':
            self.kpi_both_lane_frames += 1
        elif target_mode == 'left_only':
            self.kpi_left_only_frames += 1
        elif target_mode == 'right_only':
            self.kpi_right_only_frames += 1
        elif target_mode == 'memory':
            self.kpi_memory_frames += 1
        elif target_mode == 'kalman_only':
            self.kpi_kalman_only_frames += 1

        if not left_good and not right_good:
            self.kpi_no_lane_frames += 1

        if left_good:
            self.kpi_left_detected_frames += 1

        if right_good:
            self.kpi_right_detected_frames += 1

        self.kpi_processing_time_sum_ms += processing_time_ms
        self.kpi_processing_time_max_ms = max(self.kpi_processing_time_max_ms, processing_time_ms)

        self.kpi_left_conf_sum += float(left_conf)
        self.kpi_right_conf_sum += float(right_conf)

        self.kpi_speed_sum += float(speed)
        self.kpi_steering_sum += float(smoothed_steering_angle)

        abs_from_center = abs(float(smoothed_steering_angle) - 90.0)
        self.kpi_abs_steering_from_center_sum += abs_from_center
        self.kpi_max_abs_steering_from_center = max(self.kpi_max_abs_steering_from_center, abs_from_center)

        if self.kpi_prev_smoothed_angle is None:
            steering_change = 0.0
        else:
            steering_change = abs(float(smoothed_steering_angle) - self.kpi_prev_smoothed_angle)

        self.kpi_prev_smoothed_angle = float(smoothed_steering_angle)
        self.kpi_steering_delta_sum += steering_change
        self.kpi_max_steering_delta = max(self.kpi_max_steering_delta, steering_change)

        average_fps = (
            self.kpi_total_frames / elapsed_time_s
            if elapsed_time_s > 1e-9
            else None
        )

        lookahead_mid_x = None
        measured_mid_x = None
        predicted_mid_x = None
        target_forward_m = None
        target_lateral_m = None

        if lookahead_data is not None:
            lookahead_mid_x = lookahead_data.get('mid_x')
            measured_mid_x = lookahead_data.get('measured_mid_x')
            predicted_mid_x = lookahead_data.get('predicted_mid_x')
            target_forward_m = lookahead_data.get('target_forward_m')
            target_lateral_m = lookahead_data.get('target_lateral_m')

        row = {
            'frame': self._frame_count,
            'unix_time_s': self._kpi_format(frame_wall_time, 3),
            'elapsed_time_s': self._kpi_format(elapsed_time_s, 3),
            'processing_time_ms': self._kpi_format(processing_time_ms, 3),
            'instant_fps': self._kpi_format(instant_fps, 3),
            'average_fps': self._kpi_format(average_fps, 3),
            'frame_width_px': frame_w,
            'frame_height_px': frame_h,
            'roi_start_px': roi_start,
            'roi_end_px': roi_end,
            'left_detected': int(bool(left_good)),
            'right_detected': int(bool(right_good)),
            'both_lanes_detected': int(bool(left_good and right_good)),
            'one_lane_detected': int(bool(left_good ^ right_good)),
            'no_lane_detected': int(bool((not left_good) and (not right_good))),
            'left_confidence': self._kpi_format(left_conf, 4),
            'right_confidence': self._kpi_format(right_conf, 4),
            'has_pure_pursuit_target': int(bool(has_pure_pursuit_target)),
            'target_mode': target_mode,
            'detection_status': detection_status,
            'lookahead_mid_x_px': self._kpi_format(lookahead_mid_x, 3),
            'measured_mid_x_px': self._kpi_format(measured_mid_x, 3),
            'predicted_mid_x_px': self._kpi_format(predicted_mid_x, 3),
            'target_forward_m': self._kpi_format(target_forward_m, 4),
            'target_lateral_m': self._kpi_format(target_lateral_m, 4),
            'raw_steering_angle_deg': self._kpi_format(raw_steering_angle, 3),
            'smoothed_steering_angle_deg': self._kpi_format(smoothed_steering_angle, 3),
            'steering_change_deg': self._kpi_format(steering_change, 3),
            'abs_steering_from_center_deg': self._kpi_format(abs_from_center, 3),
            'speed_command': self._kpi_format(speed, 3),
            'prev_lane_width_px': self._kpi_format(self.prev_lane_width_px, 3),
        }

        try:
            with open(self.kpi_file, 'a', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=self.kpi_fields)
                writer.writerow(row)

            if self.kpi_total_frames == 1 or self.kpi_total_frames % self.kpi_summary_interval == 0:
                self._write_kpi_summary()

        except OSError as exc:
            self.get_logger().warn(f'Could not write KPI metrics. Error: {exc}')

    def _percentage(self, count: int) -> float:
        """Return count as a percentage of total KPI frames."""
        if self.kpi_total_frames <= 0:
            return 0.0

        return 100.0 * float(count) / float(self.kpi_total_frames)

    def _write_kpi_summary(self):
        """Write a human-readable KPI summary file in lane_debug."""
        if not self.kpi_logging_enabled:
            return

        elapsed_time_s = time.perf_counter() - self.kpi_start_perf_time
        total = max(1, self.kpi_total_frames)

        avg_processing_ms = self.kpi_processing_time_sum_ms / float(total)
        avg_fps = self.kpi_total_frames / elapsed_time_s if elapsed_time_s > 1e-9 else 0.0
        avg_left_conf = self.kpi_left_conf_sum / float(total)
        avg_right_conf = self.kpi_right_conf_sum / float(total)
        avg_speed = self.kpi_speed_sum / float(total)
        avg_steering = self.kpi_steering_sum / float(total)
        avg_abs_steering = self.kpi_abs_steering_from_center_sum / float(total)
        avg_steering_change = self.kpi_steering_delta_sum / float(total)

        summary = f"""LANE FOLLOWING KPI SUMMARY
Generated by lane_node.py

Important note:
These KPIs are measured inside the image-processing ROS node. They measure detection/control-command performance and timing. They do not measure true actuator physical accuracy unless actuator feedback is added and logged separately.

Run time:
- Total frames processed: {self.kpi_total_frames}
- Elapsed time: {elapsed_time_s:.3f} s
- Average FPS: {avg_fps:.3f}
- Average processing time per frame: {avg_processing_ms:.3f} ms
- Maximum processing time per frame: {self.kpi_processing_time_max_ms:.3f} ms

Detection availability:
- Frames with valid pure pursuit target: {self.kpi_valid_target_frames} ({self._percentage(self.kpi_valid_target_frames):.2f} %)
- Frames with no valid target: {self.kpi_no_target_frames} ({self._percentage(self.kpi_no_target_frames):.2f} %)
- Left lane detected frames: {self.kpi_left_detected_frames} ({self._percentage(self.kpi_left_detected_frames):.2f} %)
- Right lane detected frames: {self.kpi_right_detected_frames} ({self._percentage(self.kpi_right_detected_frames):.2f} %)
- No-lane detected frames: {self.kpi_no_lane_frames} ({self._percentage(self.kpi_no_lane_frames):.2f} %)

Target mode usage:
- Both lanes mode: {self.kpi_both_lane_frames} ({self._percentage(self.kpi_both_lane_frames):.2f} %)
- Left-only mode: {self.kpi_left_only_frames} ({self._percentage(self.kpi_left_only_frames):.2f} %)
- Right-only mode: {self.kpi_right_only_frames} ({self._percentage(self.kpi_right_only_frames):.2f} %)
- Memory mode: {self.kpi_memory_frames} ({self._percentage(self.kpi_memory_frames):.2f} %)
- Kalman-only mode: {self.kpi_kalman_only_frames} ({self._percentage(self.kpi_kalman_only_frames):.2f} %)

Confidence:
- Average left confidence: {avg_left_conf:.4f}
- Average right confidence: {avg_right_conf:.4f}

Command statistics:
- Average speed command: {avg_speed:.3f}
- Average smoothed steering angle: {avg_steering:.3f} deg
- Average absolute steering from center: {avg_abs_steering:.3f} deg
- Maximum absolute steering from center: {self.kpi_max_abs_steering_from_center:.3f} deg
- Average steering change between frames: {avg_steering_change:.3f} deg/frame
- Maximum steering change between frames: {self.kpi_max_steering_delta:.3f} deg/frame

Files:
- Per-frame CSV: {self.kpi_file}
- Summary file: {self.kpi_summary_file}

Suggested report usage:
- Processing speed KPI = Average FPS and average processing time.
- Detection availability KPI = Frames with valid pure pursuit target.
- One-lane recovery evidence = Left-only/right-only mode usage with valid target output.
- Steering command stability KPI = Average and maximum steering change between frames.
"""

        try:
            with open(self.kpi_summary_file, 'w') as f:
                f.write(summary)
        except OSError as exc:
            self.get_logger().warn(f'Could not write KPI summary. Error: {exc}')

    def destroy_node(self):
        """Write the latest KPI summary before shutting down the ROS node."""
        try:
            if hasattr(self, 'kpi_logging_enabled') and self.kpi_logging_enabled:
                self._write_kpi_summary()
        finally:
            super().destroy_node()

    # ─────────────────────────────────────────────────────────────────────
    # Debug folder helper
    # ─────────────────────────────────────────────────────────────────────
    def _prepare_debug_folder_if_needed(self):
        """Create and return frame-specific debug folder, or return None."""
        interval = int(self.get_parameter('debug_save_interval').value)
        if interval <= 0:
            return None

        if self._frame_count % interval != 0:
            return None

        debug_root = self.get_parameter('debug_dir').value
        save_dir = os.path.join(debug_root, f'frame_{self._frame_count:06d}')
        os.makedirs(save_dir, exist_ok=True)
        return save_dir

    # ─────────────────────────────────────────────────────────────────────
    # Spline lane detection with continuity, geometry, and no-reconnect checks
    # ─────────────────────────────────────────────────────────────────────
    def _spline_lane_fit(self, binary: np.ndarray):
        """
        Detect lane pixels row-by-row and fit splines.

        Main protections:
          - Process from bottom to top.
          - Track left/right continuity from the previous accepted row.
          - Use previous frame splines when available.
          - Reject rows where left crosses right.
          - Reject rows with unrealistic lane width.
          - Reject very wide horizontal runs that are unsafe for x = spline(y).
          - Stop accepting points for a lane after a large missing gap.
          - Reject points that cause a very sharp direction/slope change.
        """
        h, w = binary.shape

        margin = int(self.get_parameter('continuity_margin_px').value)
        min_fit_points = int(self.get_parameter('min_fit_points').value)
        morph_kernel_size = int(self.get_parameter('morph_kernel_size').value)

        margin = max(1, margin)
        min_fit_points = max(1, min_fit_points)
        min_run_width = max(1, morph_kernel_size)

        debug = cv2.cvtColor(binary, cv2.COLOR_GRAY2BGR)

        min_lane_separation_px = max(float(margin) * 0.5, float(min_run_width) * 2.0)
        max_single_row_jump_px = float(margin)

        max_missing_rows = int(h * 0.08)
        max_missing_rows = max(10, max_missing_rows)

        max_slope_change = 2.5

        max_safe_run_width_px = max(float(margin) * 4.0, float(w) * 0.35)

        previous_lane_width = self.prev_lane_width_px

        if previous_lane_width is not None:
            min_valid_width_px = max(min_lane_separation_px, previous_lane_width * 0.45)
            max_valid_width_px = previous_lane_width * 1.80
        else:
            min_valid_width_px = min_lane_separation_px
            max_valid_width_px = float(w)

        left_y = []
        left_x = []
        right_y = []
        right_x = []

        left_track_x = None
        right_track_x = None

        left_started = False
        right_started = False
        left_tracking_dead = False
        right_tracking_dead = False
        left_missing_rows = 0
        right_missing_rows = 0

        if self.prev_left_spline is not None:
            left_track_x = float(self.prev_left_spline.evaluate(h - 1))

        if self.prev_right_spline is not None:
            right_track_x = float(self.prev_right_spline.evaluate(h - 1))

        if left_track_x is None or right_track_x is None:
            histogram = np.sum(binary[h // 2:, :], axis=0)
            mid = w // 2

            if left_track_x is None and np.max(histogram[:mid]) > 0:
                left_track_x = float(np.argmax(histogram[:mid]))

            if right_track_x is None and np.max(histogram[mid:]) > 0:
                right_track_x = float(np.argmax(histogram[mid:]) + mid)

        def get_runs_on_row(y):
            """Return clean horizontal runs of white pixels on one row."""
            xs = np.where(binary[y, :] > 0)[0]
            if len(xs) < min_run_width:
                return []

            breaks = np.where(np.diff(xs) > 1)[0]
            run_starts = np.insert(breaks + 1, 0, 0)
            run_ends = np.append(breaks, len(xs) - 1)

            runs = []

            for start_i, end_i in zip(run_starts, run_ends):
                run_xs = xs[start_i:end_i + 1]
                run_width = int(run_xs[-1] - run_xs[0] + 1)

                if run_width < min_run_width:
                    continue

                if run_width > max_safe_run_width_px:
                    cv2.line(
                        debug,
                        (int(run_xs[0]), int(y)),
                        (int(run_xs[-1]), int(y)),
                        (0, 0, 255),
                        1,
                    )
                    continue

                center_x = float(np.mean(run_xs))
                runs.append(
                    {
                        'center': center_x,
                        'x0': int(run_xs[0]),
                        'x1': int(run_xs[-1]),
                        'width': run_width,
                    }
                )

            runs.sort(key=lambda item: item['center'])
            return runs

        def expected_left_x(y):
            """Expected left x from current tracking or previous frame memory."""
            if left_track_x is not None:
                return float(left_track_x)

            if self.prev_left_spline is not None:
                return float(self.prev_left_spline.evaluate(y))

            if right_track_x is not None and previous_lane_width is not None:
                return float(right_track_x - previous_lane_width)

            return None

        def expected_right_x(y):
            """Expected right x from current tracking or previous frame memory."""
            if right_track_x is not None:
                return float(right_track_x)

            if self.prev_right_spline is not None:
                return float(self.prev_right_spline.evaluate(y))

            if left_track_x is not None and previous_lane_width is not None:
                return float(left_track_x + previous_lane_width)

            return None

        def width_is_valid(lx, rx):
            """Check that right lane stays to the right and lane width is realistic."""
            width = float(rx - lx)
            return min_valid_width_px <= width <= max_valid_width_px

        def slope_change_ok(x_list, y_list, new_x, new_y):
            """
            Reject sudden direction changes.

            Because we process bottom-to-top, y decreases. The slope is dx/dy.
            A sharp change means the tracker probably jumped to another segment.
            """
            if len(x_list) < 2:
                return True

            x_last = float(x_list[-1])
            y_last = float(y_list[-1])
            x_prev = float(x_list[-2])
            y_prev = float(y_list[-2])

            dy_prev = y_last - y_prev
            dy_new = float(new_y) - y_last

            if abs(dy_prev) < 1e-6 or abs(dy_new) < 1e-6:
                return True

            prev_slope = (x_last - x_prev) / dy_prev
            new_slope = (float(new_x) - x_last) / dy_new

            return abs(new_slope - prev_slope) <= max_slope_change

        for y in range(h - 1, -1, -1):
            runs = get_runs_on_row(y)

            selected_left = None
            selected_right = None

            if len(runs) > 0:
                exp_left = expected_left_x(y)
                exp_right = expected_right_x(y)

                if len(runs) >= 2:
                    best_cost = None
                    best_pair = None

                    for i in range(len(runs)):
                        for j in range(i + 1, len(runs)):
                            lx = runs[i]['center']
                            rx = runs[j]['center']

                            if left_tracking_dead or right_tracking_dead:
                                continue

                            if not width_is_valid(lx, rx):
                                continue

                            if left_track_x is not None and abs(lx - left_track_x) > max_single_row_jump_px:
                                continue

                            if right_track_x is not None and abs(rx - right_track_x) > max_single_row_jump_px:
                                continue

                            if not slope_change_ok(left_x, left_y, lx, y):
                                continue

                            if not slope_change_ok(right_x, right_y, rx, y):
                                continue

                            cost = 0.0

                            if exp_left is not None:
                                cost += abs(lx - exp_left)

                            if exp_right is not None:
                                cost += abs(rx - exp_right)

                            if previous_lane_width is not None:
                                cost += 0.5 * abs((rx - lx) - previous_lane_width)

                            if exp_left is None and exp_right is None and previous_lane_width is None:
                                cost -= 0.05 * (rx - lx)

                            if best_cost is None or cost < best_cost:
                                best_cost = cost
                                best_pair = (lx, rx)

                    if best_pair is not None:
                        selected_left, selected_right = best_pair

                if len(runs) == 1 and selected_left is None and selected_right is None:
                    cx = runs[0]['center']

                    dist_left = float('inf')
                    dist_right = float('inf')

                    if exp_left is not None and not left_tracking_dead:
                        dist_left = abs(cx - exp_left)

                    if exp_right is not None and not right_tracking_dead:
                        dist_right = abs(cx - exp_right)

                    if exp_left is None and exp_right is None:
                        if cx < (w / 2.0) and not left_tracking_dead:
                            dist_left = 0.0
                        elif not right_tracking_dead:
                            dist_right = 0.0

                    if dist_left <= dist_right:
                        if dist_left <= max_single_row_jump_px:
                            if right_track_x is None or cx < right_track_x - min_lane_separation_px:
                                if slope_change_ok(left_x, left_y, cx, y):
                                    selected_left = cx
                    else:
                        if dist_right <= max_single_row_jump_px:
                            if left_track_x is None or cx > left_track_x + min_lane_separation_px:
                                if slope_change_ok(right_x, right_y, cx, y):
                                    selected_right = cx

            accepted_left = False
            accepted_right = False

            if selected_left is not None and selected_right is not None:
                if width_is_valid(selected_left, selected_right):
                    if not left_tracking_dead:
                        left_x.append(float(selected_left))
                        left_y.append(float(y))
                        left_track_x = float(selected_left)
                        left_started = True
                        left_missing_rows = 0
                        accepted_left = True
                        cv2.circle(debug, (int(selected_left), int(y)), 1, (255, 255, 0), -1)

                    if not right_tracking_dead:
                        right_x.append(float(selected_right))
                        right_y.append(float(y))
                        right_track_x = float(selected_right)
                        right_started = True
                        right_missing_rows = 0
                        accepted_right = True
                        cv2.circle(debug, (int(selected_right), int(y)), 1, (0, 165, 255), -1)

            elif selected_left is not None:
                if not left_tracking_dead:
                    if right_track_x is None or selected_left < right_track_x - min_lane_separation_px:
                        left_x.append(float(selected_left))
                        left_y.append(float(y))
                        left_track_x = float(selected_left)
                        left_started = True
                        left_missing_rows = 0
                        accepted_left = True
                        cv2.circle(debug, (int(selected_left), int(y)), 1, (255, 255, 0), -1)

            elif selected_right is not None:
                if not right_tracking_dead:
                    if left_track_x is None or selected_right > left_track_x + min_lane_separation_px:
                        right_x.append(float(selected_right))
                        right_y.append(float(y))
                        right_track_x = float(selected_right)
                        right_started = True
                        right_missing_rows = 0
                        accepted_right = True
                        cv2.circle(debug, (int(selected_right), int(y)), 1, (0, 165, 255), -1)

            if left_started and not accepted_left and not left_tracking_dead:
                left_missing_rows += 1
                if left_missing_rows > max_missing_rows:
                    left_tracking_dead = True
                    cv2.putText(
                        debug,
                        'LEFT STOPPED AFTER GAP',
                        (10, 115),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.55,
                        (0, 0, 255),
                        2,
                    )

            if right_started and not accepted_right and not right_tracking_dead:
                right_missing_rows += 1
                if right_missing_rows > max_missing_rows:
                    right_tracking_dead = True
                    cv2.putText(
                        debug,
                        'RIGHT STOPPED AFTER GAP',
                        (10, 145),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.55,
                        (0, 0, 255),
                        2,
                    )

        left_spline = self._make_spline_if_confident(left_y, left_x, h, min_fit_points)
        right_spline = self._make_spline_if_confident(right_y, right_x, h, min_fit_points)

        left_conf = self._lane_confidence(left_y, h, min_fit_points, left_tracking_dead)
        right_conf = self._lane_confidence(right_y, h, min_fit_points, right_tracking_dead)

        if left_spline is not None and right_spline is not None:
            pair_ok = self._validate_spline_pair(
                left_spline,
                right_spline,
                min_valid_width_px,
                max_valid_width_px,
            )

            if not pair_ok:
                if self.prev_left_spline is not None and self.prev_right_spline is not None:
                    y_start = max(left_spline.y[0], right_spline.y[0])
                    y_end = min(left_spline.y[-1], right_spline.y[-1])

                    if y_end > y_start:
                        y_test = np.linspace(y_start, y_end, int(y_end - y_start + 1)).astype(np.float32)

                        left_err = np.mean(
                            np.abs(left_spline.evaluate(y_test) - self.prev_left_spline.evaluate(y_test))
                        )
                        right_err = np.mean(
                            np.abs(right_spline.evaluate(y_test) - self.prev_right_spline.evaluate(y_test))
                        )

                        if left_err > right_err:
                            left_spline = None
                            left_conf = 0.0
                            cv2.putText(
                                debug,
                                'LEFT REJECTED: crossed/jumped',
                                (10, 85),
                                cv2.FONT_HERSHEY_SIMPLEX,
                                0.55,
                                (0, 0, 255),
                                2,
                            )
                        else:
                            right_spline = None
                            right_conf = 0.0
                            cv2.putText(
                                debug,
                                'RIGHT REJECTED: crossed/jumped',
                                (10, 85),
                                cv2.FONT_HERSHEY_SIMPLEX,
                                0.55,
                                (0, 0, 255),
                                2,
                            )
                    else:
                        left_spline = None
                        right_spline = None
                        left_conf = 0.0
                        right_conf = 0.0
                else:
                    left_spline = None
                    right_spline = None
                    left_conf = 0.0
                    right_conf = 0.0
                    cv2.putText(
                        debug,
                        'PAIR REJECTED: invalid width/crossing',
                        (10, 85),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.55,
                        (0, 0, 255),
                        2,
                    )

        self._draw_spline_on_roi_debug(debug, left_spline, (255, 255, 0), h, w)
        self._draw_spline_on_roi_debug(debug, right_spline, (0, 165, 255), h, w)

        cv2.putText(
            debug,
            f'L conf={left_conf:.2f}',
            (10, 25),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 255, 0),
            2,
        )
        cv2.putText(
            debug,
            f'R conf={right_conf:.2f}',
            (10, 55),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 165, 255),
            2,
        )

        return left_spline, right_spline, left_conf, right_conf, debug

    def _draw_spline_on_roi_debug(self, debug, spline, color, roi_h, roi_w):
        """Draw a spline only over its real detected y-range."""
        if spline is None:
            return

        y_start = int(max(0, spline.y[0]))
        y_end = int(min(roi_h - 1, spline.y[-1]))

        if y_end <= y_start:
            return

        y_draw = np.linspace(y_start, y_end, y_end - y_start + 1).astype(np.float32)
        x_draw = spline.evaluate(y_draw)

        pts = np.array(
            [
                [clamp_int(x, 0, roi_w - 1), clamp_int(y, 0, roi_h - 1)]
                for x, y in zip(x_draw, y_draw)
            ],
            dtype=np.int32,
        )

        cv2.polylines(debug, [pts], False, color, 2)

    def _make_spline_if_confident(self, y_values, x_values, roi_h: int, min_fit_points: int):
        """Create a spline only if there are enough row points and enough vertical coverage."""
        if len(y_values) < min_fit_points:
            return None

        confidence = self._lane_confidence(y_values, roi_h, min_fit_points, tracking_dead=False)

        if confidence <= 0.0:
            return None

        try:
            return SplineCurve(y_values, x_values)
        except ValueError:
            return None

    def _lane_confidence(self, y_values, roi_h: int, min_fit_points: int, tracking_dead: bool = False) -> float:
        """
        Calculate confidence from number of points and vertical lane coverage.

        If tracking was stopped after a missing gap, reduce confidence because
        the lane is only a partial continuous segment.
        """
        if len(y_values) == 0:
            return 0.0

        y = np.asarray(y_values, dtype=np.float32)

        point_score = min(1.0, len(y) / float(max(1, min_fit_points)))

        coverage = 0.0
        if roi_h > 1:
            coverage = float((np.max(y) - np.min(y)) / float(roi_h - 1))

        confidence = 0.5 * point_score + 0.5 * np.clip(coverage, 0.0, 1.0)

        if tracking_dead:
            confidence *= 0.85

        return float(np.clip(confidence, 0.0, 1.0))

    def _validate_spline_pair(self,
                              left_spline: SplineCurve,
                              right_spline: SplineCurve,
                              min_width_px: float,
                              max_width_px: float) -> bool:
        """
        Check if left and right splines form a valid lane pair.

        This prevents:
          - left lane crossing the right lane
          - lane width becoming too small
          - lane width becoming unrealistically large
        """
        if left_spline is None or right_spline is None:
            return False

        y_start = max(left_spline.y[0], right_spline.y[0])
        y_end = min(left_spline.y[-1], right_spline.y[-1])

        if y_end <= y_start:
            return False

        y_samples = np.linspace(y_start, y_end, int(y_end - y_start + 1)).astype(np.float32)

        left_x = left_spline.evaluate(y_samples)
        right_x = right_spline.evaluate(y_samples)

        widths = right_x - left_x
        valid = np.isfinite(widths)

        if np.sum(valid) < 2:
            return False

        widths = widths[valid]

        good_width_mask = (widths >= min_width_px) & (widths <= max_width_px)
        good_ratio = float(np.sum(good_width_mask)) / float(len(widths))

        if good_ratio < 0.75:
            return False

        median_width = float(np.median(widths))

        if median_width < min_width_px:
            return False

        if median_width > max_width_px:
            return False

        return True

    # ─────────────────────────────────────────────────────────────────────
    # Metric centerline helpers
    # ─────────────────────────────────────────────────────────────────────

    def _image_points_to_ground_array(self, x_px_array, y_px_array):
        """Convert arrays of image pixels to ground-metre points."""
        x_px_array = np.asarray(x_px_array, dtype=np.float32)
        y_px_array = np.asarray(y_px_array, dtype=np.float32)

        points = np.stack([x_px_array, y_px_array], axis=1)
        points = points.reshape(-1, 1, 2).astype(np.float32)

        ground = cv2.perspectiveTransform(points, self.image_to_ground_H)
        return ground.reshape(-1, 2).astype(np.float32)

    def _ground_points_to_image_spline(self, ground_points, roi_start: int, roi_h: int):
        """Convert ground-metre center points back into an image-space spline."""
        ground_points = np.asarray(ground_points, dtype=np.float32)

        if len(ground_points) < 2:
            return None

        points = ground_points.reshape(-1, 1, 2).astype(np.float32)
        image_points = cv2.perspectiveTransform(points, self.ground_to_image_H).reshape(-1, 2)

        center_x = image_points[:, 0]
        center_y_roi = image_points[:, 1] - float(roi_start)

        valid = (
            np.isfinite(center_x)
            & np.isfinite(center_y_roi)
            & (center_y_roi > -0.5 * roi_h)
            & (center_y_roi < 1.5 * roi_h)
            & (center_x > -2000.0)
            & (center_x < 3000.0)
        )

        center_x = center_x[valid]
        center_y_roi = center_y_roi[valid]

        if len(center_x) < 2:
            return None

        try:
            return SplineCurve(center_y_roi, center_x)
        except ValueError:
            return None

    def _compute_metric_center_spline_from_pair(self,
                                                left_spline: SplineCurve,
                                                right_spline: SplineCurve,
                                                roi_h: int,
                                                roi_start: int):
        """
        Compute the centerline using ground metres.

        This is better than simply averaging pixel x-values because the camera
        perspective is not uniform across the image.
        """
        if left_spline is None or right_spline is None:
            return None

        y_roi = np.linspace(0, roi_h - 1, roi_h).astype(np.float32)
        y_full = y_roi + float(roi_start)

        left_x = left_spline.evaluate(
            y_roi,
            extrapolate=True,
            x_min=-1000,
            x_max=2000,
        )

        right_x = right_spline.evaluate(
            y_roi,
            extrapolate=True,
            x_min=-1000,
            x_max=2000,
        )

        left_ground = self._image_points_to_ground_array(left_x, y_full)
        right_ground = self._image_points_to_ground_array(right_x, y_full)

        center_ground = (left_ground + right_ground) / 2.0

        return self._ground_points_to_image_spline(center_ground, roi_start, roi_h)

    def _compute_metric_offset_center_spline_from_one_lane(self,
                                                           boundary_spline: SplineCurve,
                                                           side: str,
                                                           roi_h: int,
                                                           roi_start: int):
        """
        Reconstruct the centerline from one visible lane using real lane width.

        side='left':
            visible boundary is the left lane.
            center is +half_width in lateral metres.

        side='right':
            visible boundary is the right lane.
            center is -half_width in lateral metres.
        """
        if boundary_spline is None:
            return None

        lane_width_m = float(self.get_parameter('lane_width_m').value)
        lane_width_m = float(np.clip(lane_width_m, 0.05, 1.00))
        half_width_m = lane_width_m / 2.0

        y_roi = np.linspace(0, roi_h - 1, roi_h).astype(np.float32)
        y_full = y_roi + float(roi_start)

        boundary_x = boundary_spline.evaluate(
            y_roi,
            extrapolate=True,
            x_min=-1000,
            x_max=2000,
        )

        boundary_ground = self._image_points_to_ground_array(boundary_x, y_full)

        center_ground = boundary_ground.copy()

        if side == 'left':
            center_ground[:, 1] += half_width_m
        elif side == 'right':
            center_ground[:, 1] -= half_width_m
        else:
            return None

        return self._ground_points_to_image_spline(center_ground, roi_start, roi_h)

    def _estimate_lane_width_px(self, left_spline: SplineCurve, right_spline: SplineCurve):
        """Estimate lane width in pixels from the overlapping distance between right and left splines."""
        if left_spline is None or right_spline is None:
            return None

        y_start = max(left_spline.y[0], right_spline.y[0])
        y_end = min(left_spline.y[-1], right_spline.y[-1])

        if y_end <= y_start:
            return None

        y_samples = np.linspace(y_start, y_end, int(y_end - y_start + 1)).astype(np.float32)

        left_x = left_spline.evaluate(y_samples)
        right_x = right_spline.evaluate(y_samples)

        widths = right_x - left_x
        valid_widths = widths[np.isfinite(widths) & (widths > 1.0)]

        if len(valid_widths) == 0:
            return None

        return float(np.median(valid_widths))

    def _pose_transform_memory_spline(self):
        """
        Return the memory spline after pose transformation.

        This node currently has no odometry/pose subscriber, so the transform is
        identity. Later, if an odometry topic is added, this is the function to
        update using vehicle pose change between frames.
        """
        if self.prev_center_spline is None:
            return None

        return self.prev_center_spline.copy()

    def _kalman_predict(self, frame_w: int):
        """Predict lookahead x even before seeing the current frame measurement."""
        if not self.kalman_initialized:
            return None

        F = np.array(
            [
                [1.0, 1.0],
                [0.0, 1.0],
            ],
            dtype=np.float32,
        )

        Q = np.array(
            [
                [4.0, 0.0],
                [0.0, 1.0],
            ],
            dtype=np.float32,
        )

        self.kalman_state = F @ self.kalman_state
        self.kalman_P = F @ self.kalman_P @ F.T + Q

        self.kalman_state[0] = np.clip(
            self.kalman_state[0],
            0.0,
            float(frame_w - 1),
        )

        return float(self.kalman_state[0])

    def _kalman_correct(self, measured_x: float, frame_w: int, measurement_noise: float):
        """Correct predicted lookahead x using detected/reconstructed centerline measurement."""
        measured_x = float(np.clip(measured_x, 0.0, float(frame_w - 1)))

        if not self.kalman_initialized:
            self.kalman_state = np.array([measured_x, 0.0], dtype=np.float32)
            self.kalman_P = np.eye(2, dtype=np.float32) * 10.0
            self.kalman_initialized = True
            return measured_x

        H = np.array([[1.0, 0.0]], dtype=np.float32)
        R = np.array([[max(float(measurement_noise), 1e-6)]], dtype=np.float32)
        z = np.array([[measured_x]], dtype=np.float32)

        y = z - H @ self.kalman_state.reshape(2, 1)
        S = H @ self.kalman_P @ H.T + R
        K = self.kalman_P @ H.T @ np.linalg.inv(S)

        corrected_state = self.kalman_state.reshape(2, 1) + K @ y

        self.kalman_state = corrected_state.flatten().astype(np.float32)
        self.kalman_P = (np.eye(2, dtype=np.float32) - K @ H) @ self.kalman_P

        self.kalman_state[0] = np.clip(
            self.kalman_state[0],
            0.0,
            float(frame_w - 1),
        )

        return float(self.kalman_state[0])

    # ─────────────────────────────────────────────────────────────────────
    # Visual debug overlay
    # ─────────────────────────────────────────────────────────────────────
    def _draw_lane_overlay(self,
                           frame: np.ndarray,
                           roi_start: int,
                           roi_end: int,
                           roi_shape,
                           left_spline,
                           right_spline,
                           center_spline,
                           valid_target: bool,
                           detection_status: str,
                           lookahead_data):
        """
        Draw the detected lanes, metric centerline, and lookahead target.

        The returned image is a full-size camera frame, not only the ROI.
        It is saved as lane_overlay.jpg and published on /lane_debug_image.
        """
        overlay = frame.copy()
        frame_h, frame_w = overlay.shape[:2]
        roi_h, _ = roi_shape

        cv2.line(overlay, (0, roi_start), (frame_w - 1, roi_start), (255, 0, 255), 2)
        cv2.line(overlay, (0, roi_end), (frame_w - 1, roi_end), (255, 0, 255), 2)

        cv2.putText(
            overlay,
            'ROI top',
            (10, max(20, roi_start - 10)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 0, 255),
            2,
        )

        cv2.putText(
            overlay,
            'ROI bottom',
            (10, min(frame_h - 10, roi_end + 25)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 0, 255),
            2,
        )

        cv2.putText(
            overlay,
            detection_status,
            (20, 35),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (255, 255, 255),
            2,
        )

        if not valid_target:
            cv2.putText(
                overlay,
                'NO VALID TARGET FOR PURE PURSUIT',
                (20, 70),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.75,
                (0, 0, 255),
                2,
            )
            return overlay

        def draw_spline(spline, color, label, label_y_index):
            if spline is None:
                return

            y_start = int(max(0, spline.y[0]))
            y_end = int(min(roi_h - 1, spline.y[-1]))

            if y_end <= y_start:
                return

            y_roi = np.linspace(y_start, y_end, y_end - y_start + 1).astype(np.float32)
            y_full = y_roi + roi_start
            x_values = spline.evaluate(y_roi)

            pts = np.array(
                [
                    [clamp_int(x, 0, frame_w - 1), clamp_int(y, 0, frame_h - 1)]
                    for x, y in zip(x_values, y_full)
                ],
                dtype=np.int32,
            )

            cv2.polylines(overlay, [pts], False, color, 3)

            cv2.putText(
                overlay,
                label,
                tuple(pts[min(len(pts) - 1, label_y_index)]),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                color,
                2,
            )

        draw_spline(left_spline, (255, 255, 0), 'LEFT SPLINE', 20)
        draw_spline(right_spline, (0, 165, 255), 'RIGHT SPLINE', 20)
        draw_spline(center_spline, (0, 255, 0), 'METRIC CENTER', 40)

        if lookahead_data is not None:
            y_full_i = clamp_int(lookahead_data['lookahead_y_full'], 0, frame_h - 1)
            mid_x_i = clamp_int(lookahead_data['mid_x'], 0, frame_w - 1)

            measured_mid_x = lookahead_data.get('measured_mid_x')
            predicted_mid_x = lookahead_data.get('predicted_mid_x')
            target_mode = lookahead_data.get('target_mode', 'none')

            cv2.line(
                overlay,
                (0, y_full_i),
                (frame_w - 1, y_full_i),
                (255, 255, 255),
                1,
            )

            cv2.circle(overlay, (mid_x_i, y_full_i), 9, (0, 0, 255), -1)

            if measured_mid_x is not None:
                measured_x_i = clamp_int(measured_mid_x, 0, frame_w - 1)
                cv2.circle(overlay, (measured_x_i, y_full_i), 6, (0, 255, 255), -1)

            if predicted_mid_x is not None:
                predicted_x_i = clamp_int(predicted_mid_x, 0, frame_w - 1)
                cv2.circle(overlay, (predicted_x_i, y_full_i), 5, (255, 0, 0), -1)

            bottom_center = (frame_w // 2, frame_h - 1)
            cv2.circle(overlay, bottom_center, 8, (255, 0, 0), -1)

            cv2.line(
                overlay,
                bottom_center,
                (mid_x_i, y_full_i),
                (0, 0, 255),
                3,
            )

            text1 = (
                f"target: x={lookahead_data['target_forward_m']:.2f}m, "
                f"y={lookahead_data['target_lateral_m']:.2f}m"
            )
            text2 = f"steering={lookahead_data['steering_angle']:.1f} deg"
            text3 = f"conf: L={lookahead_data['left_conf']:.2f}, R={lookahead_data['right_conf']:.2f}"
            text4 = f"mode: {target_mode}"

            cv2.putText(
                overlay,
                text1,
                (20, 70),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 0, 255),
                2,
            )

            cv2.putText(
                overlay,
                text2,
                (20, 100),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 0, 255),
                2,
            )

            cv2.putText(
                overlay,
                text3,
                (20, 130),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                2,
            )

            cv2.putText(
                overlay,
                text4,
                (20, 160),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                2,
            )

            cv2.putText(
                overlay,
                'LOOKAHEAD TARGET',
                (mid_x_i + 10, max(20, y_full_i - 10)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (0, 0, 255),
                2,
            )

        return overlay


# ═══════════════════════════════════════════════════════════════════════════
# ROS 2 entry point
# ═══════════════════════════════════════════════════════════════════════════

def main(args=None):
    rclpy.init(args=args)
    node = LaneDetectionNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
