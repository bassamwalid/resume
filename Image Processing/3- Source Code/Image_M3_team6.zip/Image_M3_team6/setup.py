import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'Image_M3_team6'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        (
            'share/ament_index/resource_index/packages',
            ['resource/' + package_name]
        ),
        (
            'share/' + package_name,
            ['package.xml']
        ),
        (
            os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py')
        ),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='team729-pi',
    maintainer_email='team729-pi@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'picam_node = Image_M3_team6.picam_node:main',
            'lane_node = Image_M3_team6.lane_node:main',
            'serial_bridge = Image_M3_team6.Serial_bridge:main',
        ],
    },
)
