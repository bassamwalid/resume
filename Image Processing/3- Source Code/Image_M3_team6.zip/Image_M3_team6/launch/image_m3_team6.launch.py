from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='Image_M3_team6',
            executable='picam_node',
            name='picam_node',
            output='screen'
        ),

        Node(
            package='Image_M3_team6',
            executable='lane_node',
            name='lane_node',
            output='screen'
        ),

        Node(
            package='Image_M3_team6',
            executable='serial_bridge',
            name='serial_bridge',
            output='screen'
        ),
    ])
